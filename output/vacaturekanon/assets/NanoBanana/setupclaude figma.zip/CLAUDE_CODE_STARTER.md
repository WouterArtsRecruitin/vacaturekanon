# 🚀 CLAUDE CODE STARTER PROJECT
**Klaar om in Claude Code te gebruiken**

---

## STAP 1: Kopieeer dit naar `claude-code-main.py`

```python
#!/usr/bin/env python3
"""
CLAUDE CODE MAIN AGENT
Premium website generator with Framer Motion + Three.js + Glassmorphism

Usage in Claude Code:
    python claude-code-main.py

Then provide brief via stdin or environment variable.
"""

import json
import os
from typing import TypedDict

# ===== TYPE DEFINITIONS =====

class ProjectBrief(TypedDict):
    sector: str  # E.g., "Construction", "Oil&Gas", "Manufacturing"
    audience: str  # E.g., "Project managers, 40-55 years old"
    brand_colors: dict[str, str]  # E.g., {"primary": "#FFC500", "accent": "#003A70"}
    headline: str  # E.g., "Senior Monteur Almere"
    subheading: str  # E.g., "Werktuigbouw | Techniek | Groei"
    cta_text: str  # E.g., "Solliciteer nu"
    three_d_type: str  # E.g., "rotating_object", "particle_field", "custom_geometry"
    glass_intensity: str  # E.g., "light", "medium", "strong"
    animations: list[str]  # E.g., ["scroll_reveal", "text_animate", "parallax"]

# ===== CONFIGURATION =====

BRAND_DEFAULTS = {
    "recruitin": {
        "primary": "#2C2C2C",  # Donkergrijs
        "accent": "#FF6B35",   # Oranje
        "light": "#F5F5F5",
        "dark": "#1A1A1A",
    }
}

SECTORS = {
    "construction": {
        "vibe": "industrial, technical, trustworthy",
        "keywords": ["safety", "precision", "expertise", "team"],
        "colors": ["#FF6B35", "#2C2C2C", "#E8E8E8"],
    },
    "oil_gas": {
        "vibe": "professional, technical, premium",
        "keywords": ["expertise", "reliability", "innovation", "partnership"],
        "colors": ["#1A3A52", "#FF6B35", "#F5F5F5"],
    },
    "manufacturing": {
        "vibe": "modern, efficient, innovative",
        "keywords": ["precision", "automation", "quality", "performance"],
        "colors": ["#2C2C2C", "#00A4EF", "#F5F5F5"],
    },
}

ANIMATION_PRESETS = {
    "scroll_reveal": {
        "initial": "{ opacity: 0, y: 50 }",
        "whileInView": "{ opacity: 1, y: 0 }",
        "transition": "{ duration: 0.7, ease: 'easeOut' }",
    },
    "text_animate": {
        "type": "letter_by_letter",
        "stagger": 0.05,
        "duration": 0.6,
    },
    "parallax": {
        "type": "mouse_parallax",
        "intensity": 0.1,
    },
}

# ===== GENERATE FUNCTIONS =====

def generate_project_structure(brief: ProjectBrief) -> str:
    """Generate file structure for new project"""
    structure = f"""
# Project: {brief['headline']}

## Directory Structure

```
{brief['sector'].lower()}-website/
├── src/
│   ├── 3d/
│   │   └── scenes/
│   │       └── HeroScene.tsx
│   ├── components/
│   │   ├── glass/
│   │   │   ├── GlassCard.tsx
│   │   │   └── glass.css
│   │   ├── motion/
│   │   │   ├── AnimatedText.tsx
│   │   │   └── ScrollReveal.tsx
│   │   ├── hero/
│   │   │   └── HeroSection.tsx
│   │   └── layout/
│   │       └── Navigation.tsx
│   ├── hooks/
│   │   ├── useMouseParallax.ts
│   │   └── useScrollAnimation.ts
│   ├── styles/
│   │   ├── globals.css
│   │   ├── glass.css
│   │   └── animations.css
│   ├── utils/
│   │   └── animation-presets.ts
│   └── App.tsx
├── public/
│   └── models/
├── package.json
├── tsconfig.json
├── vite.config.ts
└── tailwind.config.ts
```

## Next steps:
1. Create this structure
2. Copy component code from PREMIUM_WEBSITE_SETUP.md
3. Customize colors and content
4. Run `npm run dev`
5. Deploy to Vercel
"""
    return structure


def generate_animation_system(brief: ProjectBrief) -> str:
    """Generate Framer Motion animation presets"""
    animations_requested = brief.get("animations", [])
    
    code = '''// src/utils/animation-presets.ts
import { Variants } from "framer-motion";

export const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

export const slideUpVariants: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.23, 1, 0.320, 1] },
  },
};

export const scrollRevealVariants: Variants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94] },
  },
};

export const letterVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: "spring", damping: 12, stiffness: 200 },
  },
};

export const hoverLiftVariants: Variants = {
  rest: { y: 0 },
  hover: {
    y: -8,
    boxShadow: "0 20px 40px rgba(0,0,0,0.15)",
    transition: { duration: 0.3 },
  },
};
'''
    
    if "parallax" in animations_requested:
        code += '''
export const parallaxVariants = (offset = 0.1) => ({
  hidden: { opacity: 0, y: 100 },
  visible: (custom: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.8, delay: custom * 0.1 },
  }),
});
'''
    
    return code


def generate_hero_component(brief: ProjectBrief) -> str:
    """Generate premium hero component"""
    colors = brief["brand_colors"]
    
    code = f'''// src/components/hero/HeroSection.tsx
import React from "react";
import {{ motion }} from "framer-motion";
import {{ HeroScene }} from "@/3d/scenes/HeroScene";
import {{ GlassCard }} from "@/components/glass/GlassCard";
import {{ AnimatedText }} from "@/components/motion/AnimatedText";
import {{ slideUpVariants, containerVariants }} from "@/utils/animation-presets";

export const HeroSection: React.FC = () => {{
  return (
    <section className="relative w-full h-screen overflow-hidden" style={{ background: "#000" }}>
      {/* 3D Background */}
      <HeroScene />

      {/* Glass Content */}
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <motion.div
          variants={{containerVariants}}
          initial="hidden"
          animate="visible"
          className="max-w-2xl mx-auto text-center px-6"
        >
          <motion.h1
            variants={{slideUpVariants}}
            className="text-6xl md:text-7xl font-bold text-white mb-6"
          >
            <AnimatedText text="{brief['headline']}" />
          </motion.h1>

          <motion.p
            variants={{slideUpVariants}}
            className="text-xl text-gray-300 mb-8"
          >
            {brief['subheading']}
          </motion.p>

          <motion.div variants={{slideUpVariants}} whileHover={{ scale: 1.05 }}>
            <GlassCard intensity="strong" hover>
              <button className="px-8 py-4 text-lg font-semibold text-white hover:text-orange-400 transition-colors">
                {brief['cta_text']}
              </button>
            </GlassCard>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}};
'''
    return code


def generate_glass_system(brief: ProjectBrief) -> str:
    """Generate glassmorphism component system"""
    intensity = brief.get("glass_intensity", "medium")
    
    code = f'''// src/components/glass/GlassCard.tsx
import React from "react";
import {{ motion }} from "framer-motion";
import styles from "./glass.module.css";

interface GlassCardProps {{
  children: React.ReactNode;
  intensity?: "light" | "medium" | "strong";
  border?: boolean;
  hover?: boolean;
}}

export const GlassCard: React.FC<GlassCardProps> = ({{
  children,
  intensity = "{intensity}",
  border = true,
  hover = true,
}}) => {{
  const intensityMap = {{
    light: "blur(10px)",
    medium: "blur(20px)",
    strong: "blur(30px)",
  }};

  return (
    <motion.div
      className="glassmorphism"
      style={{
        backdropFilter: intensityMap[intensity],
        WebkitBackdropFilter: intensityMap[intensity],
      }}
      whileHover={hover ? {{ y: -4 }} : {{}}}
    >
      {{children}}
    </motion.div>
  );
}};
'''
    
    css = '''/* src/components/glass/glass.css */
.glassmorphism {
  background: rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  padding: 24px;
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow:
    0 8px 32px rgba(0, 0, 0, 0.1),
    inset 0 0 0 1px rgba(255, 255, 255, 0.1);
  will-change: transform, box-shadow;
}

.glassmorphism:hover {
  border-color: rgba(255, 255, 255, 0.3);
  box-shadow:
    0 20px 40px rgba(0, 0, 0, 0.15),
    inset 0 0 0 1px rgba(255, 255, 255, 0.1);
}
'''
    
    return f"{code}\n\n{css}"


def generate_three_js_scene(brief: ProjectBrief) -> str:
    """Generate Three.js scene"""
    scene_type = brief.get("three_d_type", "rotating_object")
    colors = brief["brand_colors"]
    
    code = f'''// src/3d/scenes/HeroScene.tsx
import React, {{ useRef, useEffect }} from "react";
import * as THREE from "three";
import {{ useMouseParallax }} from "@/hooks/useMouseParallax";

export const HeroScene: React.FC = () => {{
  const containerRef = useRef<HTMLDivElement>(null);
  const {{ mouseX, mouseY }} = useMouseParallax();

  useEffect(() => {{
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 5;

    const renderer = new THREE.WebGLRenderer({{\n      antialias: true,
      alpha: true,
    }});
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    containerRef.current.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 10, 7);
    scene.add(directionalLight);

    // 3D Object (accent color: {colors.get('accent', '#FF6B35')})
    const geometry = new THREE.IcosahedronGeometry(2, 4);
    const material = new THREE.MeshStandardMaterial({{
      color: "{colors.get('accent', '#FF6B35')}",
      metalness: 0.7,
      roughness: 0.2,
    }});
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    // Animation loop
    const animate = () => {{
      requestAnimationFrame(animate);
      mesh.rotation.x += (mouseY - mesh.rotation.x) * 0.05;
      mesh.rotation.y += (mouseX - mesh.rotation.y) * 0.05;
      mesh.position.y = Math.sin(Date.now() * 0.0005) * 0.5;
      renderer.render(scene, camera);
    }};
    animate();

    // Cleanup
    return () => {{
      containerRef.current?.removeChild(renderer.domElement);
    }};
  }}, [mouseX, mouseY]);

  return <div ref={{containerRef}} className="w-full h-full" />;
}};
'''
    return code


def generate_package_json() -> str:
    """Generate package.json"""
    return '''{
  "name": "premium-recruitment-website",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "deploy": "vercel --prod"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "framer-motion": "^11.0.0",
    "three": "^r128",
    "@react-three/fiber": "^8.13.0",
    "@react-three/drei": "^9.80.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@types/three": "^r128",
    "typescript": "^5.0.0",
    "vite": "^4.4.0",
    "tailwindcss": "^4.0.0",
    "postcss": "^8.4.0",
    "autoprefixer": "^10.4.0"
  }
}
'''


def main():
    """Main CLI interface"""
    print("\n🎨 PREMIUM WEBSITE GENERATOR")
    print("=" * 50)
    
    # Get project details
    sector = input("\nSektor (Construction/Oil&Gas/Manufacturing): ").strip()
    headline = input("Headline (e.g., 'Senior Monteur Almere'): ").strip()
    subheading = input("Subheading (e.g., 'Werktuigbouw | Techniek | Groei'): ").strip()
    cta = input("CTA Text (e.g., 'Solliciteer nu'): ").strip()
    
    brief: ProjectBrief = {
        "sector": sector,
        "audience": input("Target audience: ").strip(),
        "brand_colors": {
            "primary": input("Primary color (hex, e.g., #2C2C2C): ").strip(),
            "accent": input("Accent color (hex, e.g., #FF6B35): ").strip(),
        },
        "headline": headline,
        "subheading": subheading,
        "cta_text": cta,
        "three_d_type": "rotating_object",
        "glass_intensity": "strong",
        "animations": ["scroll_reveal", "text_animate", "parallax"],
    }
    
    # Generate files
    print("\n🚀 Generating project structure...")
    print(generate_project_structure(brief))
    
    print("\n📝 Component: Animation Presets")
    print(generate_animation_system(brief))
    
    print("\n🎯 Component: Hero Section")
    print(generate_hero_component(brief))
    
    print("\n🔮 Component: Glassmorphism System")
    print(generate_glass_system(brief))
    
    print("\n🌐 Component: Three.js 3D Scene")
    print(generate_three_js_scene(brief))
    
    print("\n📦 package.json")
    print(generate_package_json())
    
    print("\n✅ PROJECT GENERATED")
    print("Next steps:")
    print("1. Create directory structure")
    print("2. Copy components above")
    print("3. npm install")
    print("4. npm run dev")
    print("5. Deploy to Vercel: npm run deploy")


if __name__ == "__main__":
    main()
```

---

## STAP 2: Kopieeer dit naar `package.json`

```json
{
  "name": "premium-recruitment-website",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "deploy": "vercel --prod"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "framer-motion": "^11.0.0",
    "three": "r128",
    "zustand": "^4.4.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@types/three": "r128",
    "typescript": "^5.0.0",
    "vite": "^4.4.0",
    "tailwindcss": "^4.0.0",
    "postcss": "^8.4.0",
    "autoprefixer": "^10.4.0",
    "@tailwindcss/forms": "^0.5.0"
  }
}
```

---

## STAP 3: Kopieeer dit naar `vite.config.ts`

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 3000,
    strictPort: false,
  },
  build: {
    target: 'esnext',
    minify: 'terser',
    sourcemap: false,
  },
  preview: {
    port: 3000,
  },
})
```

---

## STAP 4: Kopieeer dit naar `tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "noImplicitAny": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true,
    "resolveJsonModule": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
```

---

## STAP 5: QUICK START in Claude Code

```bash
# Create project
mkdir premium-website
cd premium-website

# Copy files from above
# - claude-code-main.py
# - package.json
# - vite.config.ts
# - tsconfig.json

# Install dependencies
npm install

# Generate initial components
python claude-code-main.py

# Start development server
npm run dev

# Visit: http://localhost:3000
```

---

## STAP 6: CLAUDE PROMPT for Code Generation

Once you have the basic structure, use this in Claude Code:

```
Build the premium hero section for {brief}:

REQUIREMENTS:
- Framer Motion animations (advanced)
- Three.js 3D scene with mouse parallax
- Glassmorphism design system
- Custom animation presets
- Full TypeScript types
- Mobile responsive
- Performance optimized (60 FPS)

STRUCTURE:
1. Create HeroScene.tsx (Three.js)
2. Create AnimatedText.tsx (Framer Motion)
3. Create GlassCard.tsx (Glassmorphism)
4. Create HeroSection.tsx (Assembled)
5. Create animation-presets.ts (Reusable)
6. Add useMouseParallax hook
7. Add useScrollAnimation hook

QUALITY CHECKS:
- No template patterns
- Unique 3D scene
- Smooth animations
- Accessibility maintained
- Mobile optimized

Deploy to Vercel after.
```

---

## STAP 7: FILE REFERENCE

After generation, you'll need these additional files:

**src/hooks/useMouseParallax.ts**
```typescript
import { useEffect, useState } from 'react';

export const useMouseParallax = () => {
  const [mouseX, setMouseX] = useState(0);
  const [mouseY, setMouseY] = useState(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMouseX((e.clientX / window.innerWidth) * 2 - 1);
      setMouseY(-(e.clientY / window.innerHeight) * 2 + 1);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return { mouseX, mouseY };
};
```

**src/styles/globals.css**
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto;
  background: #000;
  color: #fff;
  overflow-x: hidden;
}

html {
  scroll-behavior: smooth;
}
```

---

## DEPLOYMENT

```bash
# Deploy to Vercel
vercel --prod

# Check performance
lighthouse https://your-site.vercel.app --view
```

---

Dit is je complete starter! 🚀
