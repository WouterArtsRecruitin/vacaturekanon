# 📝 CLAUDE CODE LANDING PAGE PROMPTS

**Copy-paste deze prompts in Claude Code**

---

## PROMPT 1: BASIC LANDING PAGE

```
Build a landing page with:
- Hero section: "Senior Monteur Vacature"
- Features: 3 benefits (salary, location, team)
- CTA section: "Apply now"
- Contact form: name, email, message

Use React + Tailwind + Framer Motion.
Colors: #FFC500 (primary), #003A70 (accent)
```

---

## PROMPT 2: PROFESSIONAL LANDING PAGE

```
Create a professional recruitment landing page for IT job.

Hero:
- Title: "Full Stack Developer Needed"
- Subtitle: "Join our team in Amsterdam"
- Image: tech office
- CTA: "Apply Now"

Sections:
1. About the role (description)
2. Tech stack (React, Node, PostgreSQL)
3. Benefits (3-4 items)
4. Testimonial (team quote)
5. Contact form

Colors from brand:
- Primary: #0066CC
- Accent: #FF6B35
- Text: #1a1a1a

Make it modern and responsive.
```

---

## PROMPT 3: ECOMMERCE LANDING PAGE

```
Build a product landing page for "Premium Headphones"

Sections:
1. Hero with product image
2. Features grid (sound quality, battery, design, price)
3. Customer testimonials (3 quotes)
4. Pricing table
5. FAQ accordion
6. Email signup form

Colors: minimalist (dark + white + accent)
Animations: smooth scroll reveals
```

---

## PROMPT 4: SERVICE LANDING PAGE

```
Create landing page for "Web Design Agency"

Include:
- Hero: "Beautiful websites that convert"
- Portfolio grid (6 projects)
- Process steps (5 steps)
- Testimonials carousel
- Pricing cards (3 tiers)
- Contact form

Make it premium, use glassmorphism for cards.
Colors: navy blue + gold accents
```

---

## PROMPT 5: WITH CUSTOM COLORS

```
Build landing page and apply Figma design tokens:

Colors:
- Primary: {{brandPrimary}}
- Accent: {{brandAccent}}
- Text: {{brandText}}
- Background: {{brandBg}}

Typography:
- Headlines: {{fontDisplay}}
- Body: {{fontBody}}

Sections:
- Hero
- Benefits (grid)
- Social proof
- CTA
- Form

Inject tokens directly into Tailwind config.
```

---

## PROMPT 6: FROM VACANCY DATA

```
Build landing page from this vacancy:

Title: Servicemonteur
Company: Heijmans
Location: Almere
Salary: €2.800-€3.400
Duties: [montage, diagnostics, teamwork]
Benefits: [good pay, modern workspace, growth]

Generate:
- Hero with salary prominent
- What you'll do (duties as bullets)
- What we offer (benefits as cards)
- Company testimonial
- WhatsApp CTA button
- Simple form (name, phone, message only)

Mobile-first design.
```

---

## PROMPT 7: A/B TESTING VERSION

```
Create 2 variants of landing page for same vacancy.

Variant A (emotional):
- Hero: emotional headline
- Focus: team culture
- CTA: "Join us"

Variant B (logical):
- Hero: facts first (salary, location)
- Focus: job details
- CTA: "Apply"

Build both, deploy both to different URLs.
Include tracking: gtag('event', 'variant_a') or variant_b
```

---

## PROMPT 8: WITH TESTIMONIAL VIDEO

```
Build landing page with embedded video testimonial.

Sections:
1. Hero
2. Video embed (YouTube or Vimeo)
3. Features
4. Text testimonial below video
5. CTA + form

Video URL: https://youtube.com/...
Testimonial: "Great company to work for"

Make video responsive (16:9 aspect ratio).
```

---

## HOW TO USE IN CLAUDE CODE

### Step 1: Start Claude Code

```bash
cd ~/landing-pages
claude code
```

### Step 2: Give prompt

Paste one of the prompts above, customize values.

### Step 3: Claude builds it

Claude will:
- Create components
- Build page
- Add animations
- Export to localhost:3000

### Step 4: View it

Open http://localhost:3000 in browser

### Step 5: Deploy

When happy:
```bash
npm run build
vercel  # or netlify
```

---

## PROMPT TEMPLATE (DIY)

Copy this template, fill in your values:

```
Build a landing page:

Hero:
- Title: [YOUR TITLE]
- Subtitle: [YOUR SUBTITLE]
- Image: [URL or description]
- CTA: [BUTTON TEXT]

Features/Benefits:
- [Feature 1]
- [Feature 2]
- [Feature 3]

Form fields:
- [Field 1]
- [Field 2]

Colors:
- Primary: [COLOR HEX]
- Accent: [COLOR HEX]

Style: [minimal/modern/luxury/playful]
```

---

## QUICK VARIATIONS

### Minimal version:
```
Build minimal landing page. Only:
- Hero section
- One feature
- Email signup form

Colors: white, black, one accent color.
No animations.
```

### Heavy animations version:
```
Build landing page with heavy animations:
- Staggered entrance animations
- Scroll-triggered reveals
- Hover effects on every element
- Smooth transitions between sections

Use Framer Motion extensively.
```

### Dark mode version:
```
Build dark mode landing page.
- Dark background: #1a1a1a
- Text: white
- Accent: bright color

High contrast for readability.
```

### Mobile-only version:
```
Build landing page optimized for mobile ONLY.
- Single column layout
- Large touch targets
- Bottom sticky CTA
- Minimal text

Test on iPhone SE (375px width).
```

---

## PROMPT WITH FIGMA COLORS

**BEFORE using this, get your Figma colors:**

1. Open Figma file
2. Right-click design
3. Copy color HEX codes
4. Paste in prompt:

```
Build landing page with Figma brand colors:

Primary: #FFC500 (extracted from Figma)
Accent: #003A70 (extracted from Figma)
Text: #2C2C2C (extracted from Figma)
Background: #F5F5F5 (extracted from Figma)

Font family:
- Display: "Sohne" (from Figma)
- Body: "Inter" (from Figma)

Use Tailwind + CSS variables to inject colors.
```

---

## ITERATE AFTER FIRST BUILD

After Claude builds it, you can say:

```
Changes:
1. Make hero taller (min-h-screen to min-h-[100vh])
2. Change button color to orange
3. Add more spacing between sections
4. Make form fields larger
5. Add subtle background pattern
```

Claude will update and hot-reload.

---

## EXPORT & USE

After you're happy:

```bash
# Build for production
npm run build

# Output: dist/ folder with HTML/CSS/JS

# Deploy to Vercel
vercel

# Or Netlify
netlify deploy --prod --dir=dist
```

---

**Dat is het! Simpel landing pages maken met Claude Code.** 🚀
