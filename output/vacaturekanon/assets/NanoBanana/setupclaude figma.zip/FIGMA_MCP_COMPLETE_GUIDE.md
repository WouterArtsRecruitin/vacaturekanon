# 🎨 FIGMA + MCP INTEGRATION HANDLEIDING
**Complete stap-voor-stap setup voor Claude Code**

---

## DEEL 1: BEGRIJPEN (Wat je gaat doen)

### De Workflow

```
Claude Code
    ↓
┌─ Design Agent (jij geeft brief)
│   ↓
│  Figma MCP (API call)
│   ↓
│  Create Figma File
│   ↓
│  Generate Design Tokens (JSON)
│   ↓
│  Export Component Specs
│
└─ Code Agent (krijgt design specs)
    ↓
   React Components
    ↓
   Live Website
```

### Wat gaat gebeuren

1. **Je geeft brief aan Claude Code**
   - Sector: "Construction"
   - Audience: "Project managers"
   - Brand colors: "#FFC500, #003A70"

2. **Design Agent maakt Figma bestand**
   - Unique design strategy
   - Color tokens
   - Component library
   - Design guidelines

3. **Figma MCP exported alles als JSON**
   - Design tokens
   - Component specs
   - Typography system
   - Spacing rules

4. **Code Agent bouwt React components**
   - Gebaseerd op Figma specs
   - Perfect aligned
   - Fully typed
   - Production-ready

---

## DEEL 2: PREREQUISITES

### Wat je nodig hebt

- ✅ Figma account (gratis is OK)
- ✅ Figma Personal Access Token
- ✅ Claude Code (gratis of Pro)
- ✅ Node.js 18+ geïnstalleerd
- ✅ Figma Editor rechten

### Checks

```bash
# Check Node.js version
node --version  # Should be v18+

# Check npm
npm --version   # Should be 9+

# Figma: Log in op figma.com
# Settings → Account → Personal access tokens
```

---

## DEEL 3: SETUP (De configuration)

### Stap 1: Figma Personal Access Token aanmaken

**In Figma (figma.com):**

1. Klik op je **profiel** (rechts boven)
2. Klik op **Settings**
3. Klik op **Account** (links)
4. Scroll naar **Personal access tokens**
5. Klik op **Generate new token**
6. Geef het een naam: `Claude Code Integration`
7. **Kopieer de token** (je ziet het maar 1x!)

**Voorbeeld:**
```
figd_ABC123XYZ456DEF789...
```

### Stap 2: Token opslaan in `.env.local`

**In je Claude Code project directory:**

```bash
# Maak .env.local file aan
touch .env.local
```

**Inhoud van `.env.local`:**

```
FIGMA_TOKEN=figd_ABC123XYZ456DEF789...
FIGMA_FILE_KEY=abc123def456...
```

⚠️ **BELANGRIJK:**
- `.env.local` in `.gitignore` zetten!
- Token NOOIT in Git committen!
- Token is persoonlijk en geheim!

```bash
# Add to .gitignore
echo ".env.local" >> .gitignore
```

### Stap 3: MCP Figma installeren

**In je Claude Code project:**

```bash
npm install figma
```

**Verificatie:**

```bash
npm list figma
# Should show: figma@^latest
```

### Stap 4: Python environment setup (voor agents)

```bash
# Create virtual environment
python3 -m venv .venv

# Activate it
source .venv/bin/activate  # macOS/Linux
# OF
.venv\Scripts\activate  # Windows

# Install dependencies
pip install python-dotenv requests
```

---

## DEEL 4: FIGMA MCP SETUP (De integratie)

### Figma MCP beschikbare endpoints

```python
# Beschikbare functies via MCP:

ENDPOINTS = {
    "get_file": {
        "description": "Get Figma file by key",
        "params": ["file_key"],
        "returns": "File metadata + structure"
    },
    
    "get_file_nodes": {
        "description": "Get specific nodes from file",
        "params": ["file_key", "node_ids"],
        "returns": "Node data (frames, components, etc.)"
    },
    
    "get_images": {
        "description": "Get image URLs from file",
        "params": ["file_key", "node_ids"],
        "returns": "Image URLs with expiry"
    },
    
    "export_component": {
        "description": "Export component as JSON/SVG",
        "params": ["file_key", "node_id", "format"],
        "returns": "Exported data"
    },
    
    "get_variables": {
        "description": "Get design tokens/variables",
        "params": ["file_key"],
        "returns": "All variables (colors, spacing, etc.)"
    },
    
    "list_files": {
        "description": "List all team files",
        "params": ["team_id"],
        "returns": "File list"
    }
}
```

---

## DEEL 5: CLAUDE CODE AGENTS SETUP

### Agent 1: Figma Setup Agent

**Bestand: `agents/figma-setup-agent.py`**

```python
#!/usr/bin/env python3
"""
FIGMA SETUP AGENT
Initializes Figma integration and creates project file
"""

import os
import json
from dotenv import load_dotenv
import requests

load_dotenv()

FIGMA_TOKEN = os.getenv("FIGMA_TOKEN")
FIGMA_API_BASE = "https://api.figma.com/v1"

class FigmaSetupAgent:
    def __init__(self):
        self.token = FIGMA_TOKEN
        self.headers = {
            "X-FIGMA-TOKEN": self.token,
            "Content-Type": "application/json"
        }
    
    def verify_token(self):
        """Verify Figma token is valid"""
        response = requests.get(
            f"{FIGMA_API_BASE}/me",
            headers=self.headers
        )
        
        if response.status_code == 200:
            user_data = response.json()
            print(f"✅ Token verified! Welcome {user_data['handle']}")
            return True
        else:
            print(f"❌ Token invalid: {response.text}")
            return False
    
    def create_project_file(self, project_name: str, team_id: str = None):
        """Create new Figma file for project"""
        
        payload = {
            "name": project_name,
            "file": {
                "name": project_name,
                "pages": [
                    {
                        "name": "Design System",
                        "frames": []
                    },
                    {
                        "name": "Components",
                        "frames": []
                    },
                    {
                        "name": "Layouts",
                        "frames": []
                    }
                ]
            }
        }
        
        # Figma creëert files via web interface
        # Geef instrukties terug
        
        instructions = f"""
📝 FIGMA FILE AANMAKEN (Handmatig)

1. Open Figma: https://www.figma.com/
2. Klik "+ New file"
3. Geef naam: "{project_name}"
4. Organiseer pagina's:
   - Design System (kleur tokens, typography)
   - Components (button, card, form, etc.)
   - Layouts (hero, section, footer)
5. Kopieer FILE KEY van URL:
   - URL: https://www.figma.com/file/[FILE_KEY]/...
   - Zet in .env.local: FIGMA_FILE_KEY=[FILE_KEY]

6. Return hier en continue met design building.
        """
        
        print(instructions)
        return instructions
    
    def get_file_structure(self, file_key: str):
        """Get existing file structure"""
        
        response = requests.get(
            f"{FIGMA_API_BASE}/files/{file_key}",
            headers=self.headers
        )
        
        if response.status_code == 200:
            file_data = response.json()
            print(json.dumps(file_data, indent=2))
            return file_data
        else:
            print(f"❌ Error: {response.text}")
            return None
    
    def export_design_tokens(self, file_key: str, output_file: str = "design-tokens.json"):
        """Export design variables as tokens"""
        
        response = requests.get(
            f"{FIGMA_API_BASE}/files/{file_key}/variables/local",
            headers=self.headers
        )
        
        if response.status_code == 200:
            variables = response.json()
            
            # Convert to design tokens format
            tokens = {
                "colors": {},
                "spacing": {},
                "typography": {},
                "shadows": {}
            }
            
            for var_id, var_data in variables.items():
                var_name = var_data.get("name", "")
                var_value = var_data.get("value", "")
                
                if "color" in var_name.lower():
                    tokens["colors"][var_name] = var_value
                elif "space" in var_name.lower():
                    tokens["spacing"][var_name] = var_value
                elif "font" in var_name.lower() or "size" in var_name.lower():
                    tokens["typography"][var_name] = var_value
                elif "shadow" in var_name.lower():
                    tokens["shadows"][var_name] = var_value
            
            # Save to file
            with open(output_file, "w") as f:
                json.dump(tokens, f, indent=2)
            
            print(f"✅ Design tokens exported to {output_file}")
            return tokens
        else:
            print(f"❌ Error: {response.text}")
            return None


def main():
    agent = FigmaSetupAgent()
    
    print("\n🎨 FIGMA SETUP AGENT")
    print("=" * 50)
    
    # Step 1: Verify token
    print("\n1️⃣  Verifying Figma token...")
    if not agent.verify_token():
        print("❌ Setup failed. Check your FIGMA_TOKEN in .env.local")
        return
    
    # Step 2: Create file or use existing
    choice = input("\nDo you have a Figma file? (yes/no): ").lower()
    
    if choice == "no":
        project_name = input("Project name (e.g., 'Heijmans - Senior Monteur'): ")
        agent.create_project_file(project_name)
    
    # Step 3: Export design tokens
    file_key = os.getenv("FIGMA_FILE_KEY")
    if file_key:
        print(f"\n2️⃣  Exporting design tokens from file {file_key}...")
        agent.export_design_tokens(file_key)
    else:
        print("⚠️  No FIGMA_FILE_KEY found. Add it to .env.local first.")


if __name__ == "__main__":
    main()
```

### Agent 2: Design System Agent

**Bestand: `agents/design-system-agent.py`**

```python
#!/usr/bin/env python3
"""
DESIGN SYSTEM AGENT
Generates design tokens based on sector + brand
"""

import json
from typing import TypedDict

class BrandColors(TypedDict):
    primary: str
    accent: str
    light: str
    dark: str

class DesignTokens(TypedDict):
    colors: dict
    spacing: dict
    typography: dict
    shadows: dict
    animations: dict

class DesignSystemAgent:
    def __init__(self):
        self.tokens: DesignTokens = {
            "colors": {},
            "spacing": {},
            "typography": {},
            "shadows": {},
            "animations": {}
        }
    
    def generate_color_system(self, sector: str, brand_colors: BrandColors):
        """Generate complete color system from brand colors"""
        
        primary = brand_colors["primary"]
        accent = brand_colors["accent"]
        
        # Color palette generation
        self.tokens["colors"] = {
            # Brand colors
            "color-primary": primary,
            "color-accent": accent,
            "color-light": brand_colors["light"],
            "color-dark": brand_colors["dark"],
            
            # Semantic colors
            "color-success": "#10b981",
            "color-warning": "#f59e0b",
            "color-error": "#ef4444",
            "color-info": "#3b82f6",
            
            # Neutral scale
            "color-white": "#ffffff",
            "color-black": "#000000",
            "color-gray-50": "#f9fafb",
            "color-gray-100": "#f3f4f6",
            "color-gray-200": "#e5e7eb",
            "color-gray-300": "#d1d5db",
            "color-gray-400": "#9ca3af",
            "color-gray-500": "#6b7280",
            "color-gray-600": "#4b5563",
            "color-gray-700": "#374151",
            "color-gray-800": "#1f2937",
            "color-gray-900": "#111827",
            
            # Glass morphism overlays
            "color-glass-light": "rgba(255, 255, 255, 0.15)",
            "color-glass-medium": "rgba(255, 255, 255, 0.1)",
            "color-glass-strong": "rgba(255, 255, 255, 0.05)",
        }
        
        return self.tokens["colors"]
    
    def generate_spacing_scale(self):
        """Generate spacing system (8px base)"""
        
        base = 8
        self.tokens["spacing"] = {
            "space-xs": f"{base * 1}px",    # 8px
            "space-sm": f"{base * 2}px",    # 16px
            "space-md": f"{base * 3}px",    # 24px
            "space-lg": f"{base * 4}px",    # 32px
            "space-xl": f"{base * 5}px",    # 40px
            "space-2xl": f"{base * 6}px",   # 48px
            "space-3xl": f"{base * 8}px",   # 64px
            "space-4xl": f"{base * 12}px",  # 96px
        }
        
        return self.tokens["spacing"]
    
    def generate_typography(self):
        """Generate typography system"""
        
        self.tokens["typography"] = {
            "font-family-display": "'Sohne', -apple-system, sans-serif",
            "font-family-body": "'Inter', -apple-system, sans-serif",
            "font-family-mono": "'Fira Code', monospace",
            
            # Sizes
            "font-size-xs": "12px",
            "font-size-sm": "14px",
            "font-size-base": "16px",
            "font-size-lg": "18px",
            "font-size-xl": "20px",
            "font-size-2xl": "24px",
            "font-size-3xl": "30px",
            "font-size-4xl": "36px",
            "font-size-5xl": "48px",
            "font-size-6xl": "60px",
            
            # Line heights
            "line-height-tight": "1.2",
            "line-height-snug": "1.375",
            "line-height-normal": "1.5",
            "line-height-relaxed": "1.625",
            "line-height-loose": "2",
            
            # Font weights
            "font-weight-regular": "400",
            "font-weight-medium": "500",
            "font-weight-semibold": "600",
            "font-weight-bold": "700",
        }
        
        return self.tokens["typography"]
    
    def generate_shadows(self):
        """Generate shadow system"""
        
        self.tokens["shadows"] = {
            "shadow-xs": "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
            "shadow-sm": "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
            "shadow-md": "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
            "shadow-lg": "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
            "shadow-xl": "0 20px 25px -5px rgba(0, 0, 0, 0.1)",
            "shadow-2xl": "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
        }
        
        return self.tokens["shadows"]
    
    def generate_animations(self):
        """Generate animation tokens"""
        
        self.tokens["animations"] = {
            "duration-fast": "150ms",
            "duration-base": "200ms",
            "duration-slow": "300ms",
            "duration-slower": "500ms",
            
            "easing-ease-in": "cubic-bezier(0.4, 0, 1, 1)",
            "easing-ease-out": "cubic-bezier(0, 0, 0.2, 1)",
            "easing-ease-in-out": "cubic-bezier(0.4, 0, 0.2, 1)",
            "easing-smooth": "cubic-bezier(0.25, 0.46, 0.45, 0.94)",
            "easing-bounce": "cubic-bezier(0.68, -0.55, 0.265, 1.55)",
        }
        
        return self.tokens["animations"]
    
    def export_to_json(self, filename: str = "design-tokens.json"):
        """Export all tokens to JSON"""
        
        with open(filename, "w") as f:
            json.dump(self.tokens, f, indent=2)
        
        print(f"✅ Design tokens exported to {filename}")
        return self.tokens
    
    def export_to_figma_variables(self, filename: str = "figma-variables.json"):
        """Export tokens in Figma Variables format"""
        
        figma_format = {
            "variables": {}
        }
        
        for category, items in self.tokens.items():
            for name, value in items.items():
                figma_format["variables"][f"{category}/{name}"] = {
                    "type": category,
                    "value": value
                }
        
        with open(filename, "w") as f:
            json.dump(figma_format, f, indent=2)
        
        print(f"✅ Figma variables exported to {filename}")
        return figma_format
    
    def export_to_css(self, filename: str = "design-tokens.css"):
        """Export tokens as CSS custom properties"""
        
        css_content = ":root {\n"
        
        for category, items in self.tokens.items():
            css_content += f"  /* {category.upper()} */\n"
            for name, value in items.items():
                css_content += f"  --{name}: {value};\n"
        
        css_content += "}\n"
        
        with open(filename, "w") as f:
            f.write(css_content)
        
        print(f"✅ CSS tokens exported to {filename}")
        return css_content


def main():
    # Example usage
    brand_colors: BrandColors = {
        "primary": "#2C2C2C",    # Recruitin donkergrijs
        "accent": "#FF6B35",     # Recruitin oranje
        "light": "#F5F5F5",
        "dark": "#1A1A1A",
    }
    
    agent = DesignSystemAgent()
    
    print("\n🎨 DESIGN SYSTEM GENERATOR")
    print("=" * 50)
    
    # Generate all systems
    print("\n1️⃣  Generating color system...")
    agent.generate_color_system("construction", brand_colors)
    
    print("2️⃣  Generating spacing scale...")
    agent.generate_spacing_scale()
    
    print("3️⃣  Generating typography...")
    agent.generate_typography()
    
    print("4️⃣  Generating shadows...")
    agent.generate_shadows()
    
    print("5️⃣  Generating animations...")
    agent.generate_animations()
    
    # Export in multiple formats
    print("\n📤 Exporting tokens...")
    agent.export_to_json("design-tokens.json")
    agent.export_to_css("design-tokens.css")
    agent.export_to_figma_variables("figma-variables.json")
    
    print("\n✅ DESIGN SYSTEM GENERATED")
    print("   - design-tokens.json (for code)")
    print("   - design-tokens.css (for styles)")
    print("   - figma-variables.json (for Figma import)")


if __name__ == "__main__":
    main()
```

---

## DEEL 6: FIGMA PLUGIN SETUP (Manual)

### Wat is een Figma Plugin?

Een Figma Plugin laat je **automatisch** design tokens genereren vanuit Figma.

### Eenvoudige Plugin-alternatief: Design Tokens Export

**In plaats van custom plugin, gebruik:**

1. **Figma Tokens by Design Tokens** (gratis plugin)
   - Open Figma → Plugins → "Figma Tokens"
   - Laat tokens UI beheren
   - Export als JSON
   - Automatisch gesynchroniseerd

2. **Penpot (open source alternative)**
   - Figma alternatief
   - Native design tokens
   - Direct API integration
   - Kosteloos zelf hosten

### Handmatige alternatief (wat wij doen)

**Gebruik Claude Code om:**

```python
# agents/figma-exporter.py

"""
Manual Figma exporter
- Read design file structure
- Extract components
- Generate specs
- Export as JSON
"""

def extract_components_from_figma(file_key, node_ids):
    """Get component data from Figma API"""
    
    response = requests.get(
        f"https://api.figma.com/v1/files/{file_key}/nodes",
        params={"ids": ",".join(node_ids)},
        headers={"X-FIGMA-TOKEN": FIGMA_TOKEN}
    )
    
    components = response.json()["nodes"]
    
    # Extract specs
    specs = {
        "components": [],
        "colors": [],
        "typography": []
    }
    
    for node_id, node in components.items():
        if node["type"] == "COMPONENT":
            specs["components"].append({
                "name": node["name"],
                "width": node["absoluteBoundingBox"]["width"],
                "height": node["absoluteBoundingBox"]["height"],
                "fills": node.get("fills", []),
                "children": [c["id"] for c in node.get("children", [])]
            })
    
    return specs
```

---

## DEEL 7: STAP-VOOR-STAP SETUP WIZARD

### Volledige workflow in 10 stappen

**Stap 1-3: Environment voorbereiding**

```bash
# 1. Create project directory
mkdir premium-recruitment-site
cd premium-recruitment-site

# 2. Initialize node project
npm init -y

# 3. Create .env.local
cat > .env.local << EOF
FIGMA_TOKEN=figd_YOUR_TOKEN_HERE
FIGMA_FILE_KEY=your_file_key_here
EOF
```

**Stap 4-6: Figma setup**

```bash
# 4. Open Figma: figma.com
# 5. Create new file: "Recruitment Site Design"
# 6. Get FILE KEY from URL and paste in .env.local
```

**Stap 7-10: Claude Code setup**

```bash
# 7. Create agents directory
mkdir agents

# 8. Copy figma-setup-agent.py (from above)
# 9. Copy design-system-agent.py (from above)

# 10. Run setup
python3 agents/figma-setup-agent.py
python3 agents/design-system-agent.py
```

---

## DEEL 8: FIGMA → CODE WORKFLOW

### Complete end-to-end flow

```
┌─ FIGMA (Design)
│
├─ 1. Create design system in Figma
│    - Colors
│    - Typography
│    - Components
│    - Layouts
│
├─ 2. Export design tokens
│    → design-tokens.json
│    → design-tokens.css
│    → figma-variables.json
│
├─ 3. Commit to GitHub
│
└─ 4. Claude Code reads tokens
     ↓
     Generate React components
     ↓
     Use design tokens in code
     ↓
     Perfect alignment! 🎯
```

### Praktijkvoorbeeld

**Figma → JSON:**

```json
{
  "colors": {
    "color-primary": "#FFC500",
    "color-accent": "#003A70",
    "color-text": "#2C2C2C"
  },
  "spacing": {
    "space-md": "24px",
    "space-lg": "32px"
  }
}
```

**React component (automatic):**

```typescript
// src/components/Button.tsx
import { colors, spacing } from '@/tokens/design-tokens.json';

export const Button = () => (
  <button
    style={{
      backgroundColor: colors['color-primary'],
      padding: spacing['space-md'],
      color: colors['color-text']
    }}
  >
    Click me
  </button>
);
```

---

## DEEL 9: TROUBLESHOOTING

### ❌ "Invalid token" error

```
Solution:
1. Check FIGMA_TOKEN in .env.local
2. Make sure token is complete (figd_...)
3. Token might be expired → regenerate in Figma
4. Check .env.local is NOT in .gitignore accidentally
```

### ❌ "File not found" error

```
Solution:
1. Check FIGMA_FILE_KEY in .env.local
2. FILE_KEY is from URL: figma.com/file/[THIS_PART]/...
3. Make sure you have access to file
4. File must not be archived
```

### ❌ "Rate limit exceeded"

```
Solution:
1. Figma API has limits: 300 requests/minute
2. Cache design tokens locally
3. Don't regenerate constantly
4. Use GitHub Actions for scheduled updates
```

### ❌ "Design tokens not syncing"

```
Solution:
1. Make sure Figma variables exist
2. Use correct variable names
3. Regenerate tokens: python3 agents/design-system-agent.py
4. Check JSON format is valid
```

---

## DEEL 10: ADVANCED: GitHub Actions Auto-Sync

**Bestand: `.github/workflows/figma-sync.yml`**

```yaml
name: Figma Design Tokens Sync

on:
  schedule:
    - cron: '0 9 * * *'  # Daily at 9 AM
  workflow_dispatch:

jobs:
  sync:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          pip install python-dotenv requests
      
      - name: Export design tokens
        env:
          FIGMA_TOKEN: ${{ secrets.FIGMA_TOKEN }}
          FIGMA_FILE_KEY: ${{ secrets.FIGMA_FILE_KEY }}
        run: |
          python3 agents/design-system-agent.py
      
      - name: Commit and push
        run: |
          git config --local user.name "Figma Bot"
          git config --local user.email "figma@bot.local"
          git add design-tokens.json design-tokens.css
          git commit -m "Update design tokens from Figma" || echo "No changes"
          git push
```

---

## DEEL 11: VERVOLG MET CLAUDE CODE

### Main Agent Prompt (integratie met Figma)

```python
# Claude Code Main Agent Prompt

main_agent_prompt = """
You are the Premium Website + Figma Integration Agent.

INTEGRATED WORKFLOW:

1. USER gives brief (sector, brand colors, etc.)

2. YOU call Design System Agent:
   - Generate design tokens
   - Create JSON specs
   - Export CSS variables

3. FIGMA SETUP:
   - Check .env.local has FIGMA_TOKEN + FIGMA_FILE_KEY
   - Export design variables from Figma
   - Get color palette, typography, spacing

4. MERGE TOKENS:
   - Combine Figma exports + generated tokens
   - Create unified design system
   - Export to design-tokens.json

5. CODE GENERATION:
   - Use tokens to build React components
   - Import design-tokens.json in components
   - Perfect alignment guaranteed

COMMANDS AVAILABLE:
- python3 agents/figma-setup-agent.py → Setup Figma
- python3 agents/design-system-agent.py → Generate tokens
- node scripts/figma-export.js → Export from Figma

BEST PRACTICE:
1. Always export tokens from Figma first
2. Generate design system
3. Then build components
4. Never hard-code colors/spacing
5. Always use tokens
"""
```

---

## DEEL 12: PRODUCTION CHECKLIST

### Voor live deployment

- [ ] Tokens exported van Figma
- [ ] design-tokens.json in repo
- [ ] design-tokens.css gelinkt in HTML
- [ ] React components gebruiken tokens
- [ ] TypeScript types voor tokens
- [ ] CSS variables werken op alle browsers
- [ ] Design system dokumentatie klaar
- [ ] Team access tot Figma file
- [ ] GitHub Actions sync geconfigureerd
- [ ] Vercel deployment checked

---

## DEEL 13: VOLGENDE STAPPEN

### Wat ga je nu doen?

**A) Setup compleet**
```bash
# 1. Copy agents naar je project
# 2. Create .env.local
# 3. Set FIGMA_TOKEN + FIGMA_FILE_KEY
# 4. python3 agents/figma-setup-agent.py
# 5. python3 agents/design-system-agent.py
# 6. Check design-tokens.json
# 7. Ready!
```

**B) Figma file maken**
- Open figma.com
- Create new file
- Name it: "[Project] Design System"
- Create pages: Colors, Typography, Components
- Export FILE_KEY
- Paste in .env.local

**C) Eerste component bouwen**
```bash
# Claude Code command:
# "Build GlassCard component using design tokens
#  - Import from design-tokens.json
#  - Use color-primary, color-accent
#  - Use space-md, space-lg spacing
#  - Make it TypeScript + production-ready"
```

---

## DEEL 14: RESOURCES

### Documentatie

- **Figma API**: https://www.figma.com/developers/api
- **Figma Tokens**: https://figma-tokens.studio/
- **Design Tokens W3C**: https://design-tokens.github.io/community-group/format/
- **Figma Plugins**: https://www.figma.com/plugin/

### Tools

- **Figma Tokens by Design Tokens**: Free plugin
- **Design Tokens plugin**: Color export
- **Figma Variables**: Native tokens (beta)
- **Penpot**: Open source alternative

### GitHub resources

```bash
# Design token examples
git clone https://github.com/design-tokens/community-group

# Figma API examples
git clone https://github.com/figma/plugin-samples
```

---

Dit is je complete Figma + MCP guide! 🎨

Volgende: Zeg wat je sector is, dan helpen we met setup! 🚀
