# 🎯 PRAKTIJK VOORBEELD: HEIJMANS PROJECT
**Complete werkend voorbeeld met echte code**

---

## SCENARIO

Je bouwt website voor: **Heijmans - Senior Uitvoerder Wegen**
- Sector: Construction/Civil Works
- Brand: Geel #FFC500, Navy #003A70, Rood #E31C23
- Target: Project managers, 40-55 years
- Goal: Recruitment landing page

---

## STAP 1: PROJECT SETUP

```bash
# Create project
mkdir heijmans-website
cd heijmans-website

# Initialize
npm init -y

# Create structure
mkdir -p agents src/components src/styles src/utils src/tokens
touch .env.local .gitignore

# Create .gitignore
cat > .gitignore << 'EOF'
node_modules/
.env.local
.env*.local
dist/
build/
.next/
.vercel/
EOF
```

---

## STAP 2: FIGMA SETUP (Handmatig)

### In browser (figma.com):

1. **Open Figma → Create new file**
   ```
   Name: "Heijmans - Wegen Recruitment"
   ```

2. **Create 4 pages:**
   - Color System
   - Typography
   - Components
   - Layouts

3. **Page 1: Color System**
   - Create frame "Brand Colors"
   - Add rectangles:
     - Geel: #FFC500
     - Navy: #003A70
     - Rood: #E31C23
     - White: #FFFFFF
     - Gray: #F5F5F5

4. **Page 2: Typography**
   - Headings: "Sohne Bold 48px"
   - Body: "Inter Regular 16px"
   - Caption: "Inter Regular 12px"

5. **Page 3: Components**
   - Button (using Geel + Navy)
   - Card (with Navy border)
   - Input field

6. **Page 4: Layouts**
   - Hero section frame
   - Feature section frame

7. **Copy FILE KEY from URL:**
   ```
   URL: https://www.figma.com/file/ABC123XYZ456/Heijmans...
                                         ^^^^^^^^^^^^^^^^
                                         This is FILE_KEY
   ```

---

## STAP 3: .env.local

```bash
# .env.local
FIGMA_TOKEN=figd_YOUR_TOKEN_HERE
FIGMA_FILE_KEY=ABC123XYZ456
PROJECT_NAME=Heijmans - Wegen Recruitment
SECTOR=construction
BRAND_PRIMARY=#FFC500
BRAND_ACCENT=#003A70
BRAND_TERTIARY=#E31C23
```

---

## STAP 4: Design Tokens Generator (Aangepast voor Heijmans)

**Bestand: `agents/heijmans-tokens.py`**

```python
#!/usr/bin/env python3
"""
HEIJMANS DESIGN TOKENS GENERATOR
Specific tokens for construction/wegen recruitment site
"""

import json
import os
from dotenv import load_dotenv

load_dotenv()

class HeijmansDesignSystem:
    def __init__(self):
        # Brand colors (van .env)
        self.primary = os.getenv("BRAND_PRIMARY", "#FFC500")  # Geel
        self.accent = os.getenv("BRAND_ACCENT", "#003A70")    # Navy
        self.tertiary = os.getenv("BRAND_TERTIARY", "#E31C23") # Rood
        
        self.tokens = {
            "colors": {},
            "spacing": {},
            "typography": {},
            "shadows": {},
            "animations": {},
            "borders": {},
        }
    
    def generate_heijmans_colors(self):
        """Generate color system with Heijmans branding"""
        
        self.tokens["colors"] = {
            # Brand colors
            "primary": self.primary,      # Geel #FFC500
            "accent": self.accent,        # Navy #003A70
            "tertiary": self.tertiary,    # Rood #E31C23
            
            # Semantic (for construction)
            "success": "#10b981",         # Green (completed)
            "warning": self.tertiary,     # Red (urgent/important)
            "error": "#ef4444",           # Error state
            "info": self.accent,          # Info (navy)
            
            # Neutral scale (for safety/trust)
            "white": "#FFFFFF",
            "black": "#000000",
            "gray-50": "#F9FAFB",
            "gray-100": "#F3F4F6",
            "gray-200": "#E5E7EB",
            "gray-300": "#D1D5DB",
            "gray-400": "#9CA3AF",
            "gray-500": "#6B7280",
            "gray-600": "#4B5563",
            "gray-700": "#374151",
            "gray-800": "#1F2937",
            "gray-900": "#111827",
            
            # Text colors
            "text-primary": "#1F2937",
            "text-secondary": "#6B7280",
            "text-light": "#9CA3AF",
            "text-white": "#FFFFFF",
            
            # Background colors
            "bg-white": "#FFFFFF",
            "bg-light": "#F9FAFB",
            "bg-dark": "#1F2937",
            "bg-navy": self.accent,
            
            # Glass morphism (for modern touch)
            "glass-light": "rgba(255, 255, 255, 0.15)",
            "glass-medium": "rgba(255, 255, 255, 0.1)",
            "glass-dark": "rgba(0, 0, 0, 0.05)",
        }
        
        return self.tokens["colors"]
    
    def generate_spacing(self):
        """Spacing system (construction-themed: solid, clear)"""
        
        self.tokens["spacing"] = {
            "xs": "4px",
            "sm": "8px",
            "md": "16px",
            "lg": "24px",
            "xl": "32px",
            "2xl": "48px",
            "3xl": "64px",
            "4xl": "96px",
            
            # Container widths
            "container-sm": "640px",
            "container-md": "768px",
            "container-lg": "1024px",
            "container-xl": "1280px",
        }
        
        return self.tokens["spacing"]
    
    def generate_typography(self):
        """Typography for construction industry (solid, trustworthy)"""
        
        self.tokens["typography"] = {
            # Font families
            "font-display": "'Sohne', -apple-system, sans-serif",  # Headings
            "font-body": "'Inter', -apple-system, sans-serif",     # Body text
            "font-mono": "'Fira Code', monospace",                  # Code/data
            
            # Font sizes
            "text-xs": "12px",
            "text-sm": "14px",
            "text-base": "16px",
            "text-lg": "18px",
            "text-xl": "20px",
            "text-2xl": "24px",
            "text-3xl": "30px",
            "text-4xl": "36px",
            "text-5xl": "48px",
            "text-6xl": "60px",
            
            # Line heights (safety/readability)
            "leading-tight": "1.2",
            "leading-snug": "1.375",
            "leading-normal": "1.5",
            "leading-relaxed": "1.625",
            "leading-loose": "2",
            
            # Font weights (solid look)
            "weight-regular": "400",
            "weight-medium": "500",
            "weight-semibold": "600",
            "weight-bold": "700",
            
            # Typographic scales (specific)
            "h1": {
                "font-size": "48px",
                "font-weight": "700",
                "line-height": "1.2",
                "font-family": "Sohne"
            },
            "h2": {
                "font-size": "36px",
                "font-weight": "700",
                "line-height": "1.2",
                "font-family": "Sohne"
            },
            "h3": {
                "font-size": "24px",
                "font-weight": "600",
                "line-height": "1.3",
                "font-family": "Sohne"
            },
            "body": {
                "font-size": "16px",
                "font-weight": "400",
                "line-height": "1.5",
                "font-family": "Inter"
            },
            "caption": {
                "font-size": "12px",
                "font-weight": "400",
                "line-height": "1.4",
                "font-family": "Inter"
            }
        }
        
        return self.tokens["typography"]
    
    def generate_shadows(self):
        """Shadows for construction site aesthetic (solid, trustworthy)"""
        
        self.tokens["shadows"] = {
            "none": "none",
            "xs": "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
            "sm": "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
            "md": "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
            "lg": "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
            "xl": "0 20px 25px -5px rgba(0, 0, 0, 0.1)",
            "2xl": "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
            
            # Navy accent shadows
            "accent-sm": f"0 4px 6px -1px {self.accent}20",
            "accent-md": f"0 10px 15px -3px {self.accent}30",
        }
        
        return self.tokens["shadows"]
    
    def generate_animations(self):
        """Animations (construction: direct, purposeful)"""
        
        self.tokens["animations"] = {
            "duration-fast": "150ms",
            "duration-normal": "200ms",
            "duration-slow": "300ms",
            "duration-slower": "500ms",
            
            "easing-linear": "linear",
            "easing-in": "cubic-bezier(0.4, 0, 1, 1)",
            "easing-out": "cubic-bezier(0, 0, 0.2, 1)",
            "easing-in-out": "cubic-bezier(0.4, 0, 0.2, 1)",
            "easing-smooth": "cubic-bezier(0.25, 0.46, 0.45, 0.94)",
        }
        
        return self.tokens["animations"]
    
    def generate_borders(self):
        """Borders (construction: solid, defined)"""
        
        self.tokens["borders"] = {
            "radius-none": "0",
            "radius-sm": "4px",
            "radius-md": "8px",
            "radius-lg": "12px",
            "radius-xl": "16px",
            "radius-2xl": "24px",
            "radius-full": "9999px",
            
            # Border widths
            "width-1": "1px",
            "width-2": "2px",
            "width-4": "4px",
            
            # Border colors
            "border-light": "#E5E7EB",
            "border-navy": self.accent,
            "border-yellow": self.primary,
        }
        
        return self.tokens["borders"]
    
    def export_json(self, filename="src/tokens/design-tokens.json"):
        """Export to JSON"""
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        with open(filename, "w") as f:
            json.dump(self.tokens, f, indent=2)
        
        print(f"✅ Exported to {filename}")
        return self.tokens
    
    def export_css(self, filename="src/styles/design-tokens.css"):
        """Export to CSS custom properties"""
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        css = ":root {\n"
        
        # Colors
        css += "  /* COLORS */\n"
        for name, value in self.tokens["colors"].items():
            if isinstance(value, dict):
                continue
            css += f"  --color-{name}: {value};\n"
        
        # Spacing
        css += "\n  /* SPACING */\n"
        for name, value in self.tokens["spacing"].items():
            css += f"  --spacing-{name}: {value};\n"
        
        # Typography
        css += "\n  /* TYPOGRAPHY */\n"
        for name, value in self.tokens["typography"].items():
            if isinstance(value, dict):
                css += f"  /* {name} */\n"
                for k, v in value.items():
                    css += f"  --{name}-{k}: {v};\n"
            else:
                css += f"  --typography-{name}: {value};\n"
        
        # Shadows
        css += "\n  /* SHADOWS */\n"
        for name, value in self.tokens["shadows"].items():
            css += f"  --shadow-{name}: {value};\n"
        
        # Borders
        css += "\n  /* BORDERS */\n"
        for name, value in self.tokens["borders"].items():
            css += f"  --border-{name}: {value};\n"
        
        # Animations
        css += "\n  /* ANIMATIONS */\n"
        for name, value in self.tokens["animations"].items():
            css += f"  --animation-{name}: {value};\n"
        
        css += "}\n"
        
        with open(filename, "w") as f:
            f.write(css)
        
        print(f"✅ Exported to {filename}")
        return css
    
    def generate_all(self):
        """Generate all token systems"""
        print("\n🎨 HEIJMANS DESIGN SYSTEM GENERATOR")
        print("=" * 50)
        
        print("\n1️⃣  Generating colors...")
        self.generate_heijmans_colors()
        
        print("2️⃣  Generating spacing...")
        self.generate_spacing()
        
        print("3️⃣  Generating typography...")
        self.generate_typography()
        
        print("4️⃣  Generating shadows...")
        self.generate_shadows()
        
        print("5️⃣  Generating animations...")
        self.generate_animations()
        
        print("6️⃣  Generating borders...")
        self.generate_borders()
        
        print("\n📤 Exporting tokens...")
        self.export_json()
        self.export_css()
        
        print("\n✅ DESIGN SYSTEM READY!")
        print("\nFiles created:")
        print("  - src/tokens/design-tokens.json")
        print("  - src/styles/design-tokens.css")
        
        return self.tokens


def main():
    system = HeijmansDesignSystem()
    system.generate_all()


if __name__ == "__main__":
    main()
```

---

## STAP 5: Run Token Generator

```bash
# Create directory
mkdir -p agents

# Copy script above as: agents/heijmans-tokens.py

# Run it
python3 agents/heijmans-tokens.py

# Result:
# ✅ Exported to src/tokens/design-tokens.json
# ✅ Exported to src/styles/design-tokens.css
```

---

## STAP 6: Inspect Generated Files

**Bestand: `src/tokens/design-tokens.json` (gegenereerd)**

```json
{
  "colors": {
    "primary": "#FFC500",
    "accent": "#003A70",
    "tertiary": "#E31C23",
    "success": "#10b981",
    "warning": "#E31C23",
    "text-primary": "#1F2937",
    "bg-white": "#FFFFFF",
    ...
  },
  "spacing": {
    "xs": "4px",
    "sm": "8px",
    "md": "16px",
    "lg": "24px",
    ...
  },
  "typography": {
    "h1": {
      "font-size": "48px",
      "font-weight": "700",
      ...
    },
    ...
  }
}
```

**Bestand: `src/styles/design-tokens.css` (gegenereerd)**

```css
:root {
  /* COLORS */
  --color-primary: #FFC500;
  --color-accent: #003A70;
  --color-tertiary: #E31C23;
  --color-text-primary: #1F2937;
  --color-bg-white: #FFFFFF;
  
  /* SPACING */
  --spacing-xs: 4px;
  --spacing-sm: 8px;
  --spacing-md: 16px;
  --spacing-lg: 24px;
  
  /* TYPOGRAPHY */
  --h1-font-size: 48px;
  --h1-font-weight: 700;
  
  /* SHADOWS */
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  
  /* BORDERS */
  --border-radius-md: 8px;
  --border-width-1: 1px;
  
  /* ANIMATIONS */
  --animation-duration-normal: 200ms;
  --animation-easing-out: cubic-bezier(0, 0, 0.2, 1);
}
```

---

## STAP 7: Use Tokens in React Components

**Bestand: `src/components/Button.tsx`**

```typescript
import React from 'react';
import tokens from '@/tokens/design-tokens.json';
import '@/styles/design-tokens.css';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'tertiary';
  onClick?: () => void;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  onClick,
}) => {
  // Map variant to color tokens
  const variantMap = {
    primary: {
      bg: tokens.colors.primary,      // #FFC500
      text: tokens.colors.accent,     // #003A70
      border: tokens.colors.primary,
    },
    secondary: {
      bg: tokens.colors.accent,       // #003A70
      text: tokens.colors.white,      // #FFFFFF
      border: tokens.colors.accent,
    },
    tertiary: {
      bg: tokens.colors.tertiary,     // #E31C23
      text: tokens.colors.white,      // #FFFFFF
      border: tokens.colors.tertiary,
    },
  };

  const colors = variantMap[variant];

  return (
    <button
      onClick={onClick}
      style={{
        // Use spacing tokens
        padding: `${tokens.spacing.md} ${tokens.spacing.lg}`,
        
        // Use color tokens
        backgroundColor: colors.bg,
        color: colors.text,
        border: `${tokens.borders['width-2']} solid ${colors.border}`,
        
        // Use typography tokens
        fontSize: tokens.typography['text-base'],
        fontFamily: tokens.typography['font-body'],
        fontWeight: parseInt(tokens.typography['weight-semibold']),
        
        // Use border tokens
        borderRadius: tokens.borders['radius-lg'],
        
        // Use shadows tokens
        boxShadow: tokens.shadows.md,
        
        // Use animation tokens
        transition: `all ${tokens.animations['duration-normal']} ${tokens.animations['easing-out']}`,
        
        // Hover state
        cursor: 'pointer',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-2px)';
        e.currentTarget.style.boxShadow = tokens.shadows.lg;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = tokens.shadows.md;
      }}
    >
      {children}
    </button>
  );
};
```

**Bestand: `src/components/Card.tsx`**

```typescript
import React from 'react';
import '@/styles/design-tokens.css';

interface CardProps {
  children: React.ReactNode;
  highlight?: 'navy' | 'yellow';
}

export const Card: React.FC<CardProps> = ({ children, highlight = 'navy' }) => {
  const borderColor = highlight === 'navy' ? 'var(--color-accent)' : 'var(--color-primary)';

  return (
    <div
      style={{
        // Use CSS variables (automatic styling)
        backgroundColor: 'var(--color-bg-light)',
        padding: 'var(--spacing-lg)',
        borderLeft: `var(--border-width-4) solid ${borderColor}`,
        borderRadius: 'var(--border-radius-lg)',
        boxShadow: 'var(--shadow-md)',
        transition: `all var(--animation-duration-normal) var(--animation-easing-out)`,
      }}
    >
      {children}
    </div>
  );
};
```

---

## STAP 8: Figma Integration (Optional but Recommended)

**Bestand: `agents/figma-export.py`**

```python
#!/usr/bin/env python3
"""
FIGMA EXPORT AGENT
Optionally export variables from Figma to enhance design tokens
"""

import os
import requests
from dotenv import load_dotenv

load_dotenv()

FIGMA_TOKEN = os.getenv("FIGMA_TOKEN")
FILE_KEY = os.getenv("FIGMA_FILE_KEY")
API_BASE = "https://api.figma.com/v1"

class FigmaExporter:
    def __init__(self):
        self.headers = {"X-FIGMA-TOKEN": FIGMA_TOKEN}
    
    def get_file_variables(self):
        """Get variables from Figma file"""
        
        url = f"{API_BASE}/files/{FILE_KEY}/variables/local"
        response = requests.get(url, headers=self.headers)
        
        if response.status_code == 200:
            variables = response.json()
            print(f"✅ Retrieved {len(variables)} variables from Figma")
            return variables
        else:
            print(f"❌ Error: {response.text}")
            return None
    
    def export_colors_from_figma(self):
        """Export color variables from Figma"""
        
        variables = self.get_file_variables()
        if not variables:
            return None
        
        colors = {}
        for var_id, var_data in variables.items():
            name = var_data.get("name", "").lower()
            
            if "color" in name:
                value = var_data.get("value")
                colors[name.replace("/", "-")] = value
        
        print(f"✅ Extracted {len(colors)} colors")
        return colors

def main():
    exporter = FigmaExporter()
    colors = exporter.export_colors_from_figma()
    
    if colors:
        print("\nColor variables:")
        for name, value in colors.items():
            print(f"  {name}: {value}")

if __name__ == "__main__":
    main()
```

**Usage:**
```bash
python3 agents/figma-export.py
```

---

## STAP 9: Package.json

**Bestand: `package.json`**

```json
{
  "name": "heijmans-recruitment-site",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "tokens": "python3 agents/heijmans-tokens.py",
    "tokens:figma": "python3 agents/figma-export.py",
    "build": "tsc && vite build",
    "dev": "vite",
    "deploy": "vercel --prod"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "framer-motion": "^11.0.0",
    "three": "r128"
  },
  "devDependencies": {
    "typescript": "^5.0.0",
    "vite": "^4.4.0",
    "@types/react": "^18.2.0"
  }
}
```

---

## STAP 10: Workflow

```bash
# 1. Generate design tokens
npm run tokens

# 2. (Optional) Export from Figma
npm run tokens:figma

# 3. Use in React components
# → Automatic color system
# → Full TypeScript support
# → Easy maintenance

# 4. Deploy
npm run deploy
```

---

## RESULT

```
┌─ FIGMA (geel, navy, rood)
│
├─ DESIGN TOKENS
│  ├─ design-tokens.json (React)
│  └─ design-tokens.css (CSS)
│
├─ REACT COMPONENTS
│  ├─ Button (uses tokens)
│  ├─ Card (uses tokens)
│  └─ Section (uses tokens)
│
└─ LIVE SITE (heijmans-recruitment.vercel.app)
   └─ Perfect brand alignment! ✅
```

---

Dit is je complete praktijk guide! 🎯

**Volgende:**
1. Copy `heijmans-tokens.py` naar je project
2. Run: `python3 agents/heijmans-tokens.py`
3. Check: `src/tokens/design-tokens.json`
4. Use in components!

🚀
