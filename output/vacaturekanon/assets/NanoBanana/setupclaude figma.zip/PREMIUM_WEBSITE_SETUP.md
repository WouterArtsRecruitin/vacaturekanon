# 🎨 PREMIUM WEBSITE SETUP
**Framer Motion + Glassmorphism + Three.js 3D**
**Voor Wouter Arts - Recruitin B.V.**

---

## DEEL 1: TECH STACK (Premium tier)

```
Frontend Framework:    React 18 + TypeScript
Animation:             Framer Motion 11.x
3D Engine:             Three.js R128 + Three Fiber
Styling:               Tailwind CSS 4 + CSS Modules
Glass Effect:          Custom Glassmorphism library
State Management:      Zustand
Build Tool:            Vite
Deployment:            Vercel (for SSR + image optimization)
```

---

## DEEL 2: PROJECT STRUCTURE

```
premium-website/
├── src/
│   ├── 3d/                          # Three.js components
│   │   ├── scenes/
│   │   │   ├── HeroScene.tsx        # Main 3D hero
│   │   │   ├── ParticleField.tsx    # Particle animations
│   │   │   └── DataViz3D.tsx        # 3D data visualization
│   │   ├── models/
│   │   │   └── [GLTF/GLB models]
│   │   ├── hooks/
│   │   │   ├── useThreeScene.ts
│   │   │   └── useMouseTrack3D.ts
│   │   └── utils/
│   │       ├── shaders.ts           # Custom GLSL shaders
│   │       └── geometry.ts
│   │
│   ├── components/
│   │   ├── glass/                   # Glassmorphism components
│   │   │   ├── GlassCard.tsx        # Base glass component
│   │   │   ├── GlassNav.tsx
│   │   │   ├── GlassButton.tsx
│   │   │   └── GlassForm.tsx
│   │   │
│   │   ├── motion/                  # Framer Motion components
│   │   │   ├── AnimatedText.tsx     # Text reveal animations
│   │   │   ├── ScrollReveal.tsx     # Scroll-triggered
│   │   │   ├── ParallaxSection.tsx  # Parallax effect
│   │   │   └── MorphAnimation.tsx   # Shape morphing
│   │   │
│   │   ├── hero/
│   │   │   ├── HeroSection.tsx      # Premium hero + 3D
│   │   │   └── HeroBackground.tsx
│   │   │
│   │   ├── sections/
│   │   │   ├── Features3D.tsx
│   │   │   ├── Testimonials.tsx
│   │   │   ├── CaseStudy.tsx
│   │   │   └── CTASection.tsx
│   │   │
│   │   └── layout/
│   │       ├── Navigation.tsx
│   │       ├── Footer.tsx
│   │       └── Layout.tsx
│   │
│   ├── hooks/
│   │   ├── useScrollAnimation.ts     # Scroll-based animations
│   │   ├── useMouseParallax.ts      # Mouse tracking parallax
│   │   ├── useIntersection.ts       # Intersection observer
│   │   ├── useGlassEffect.ts        # Dynamic glass effect
│   │   └── use3DCamera.ts           # 3D camera control
│   │
│   ├── styles/
│   │   ├── globals.css              # Global CSS
│   │   ├── glass.css                # Glassmorphism styles
│   │   ├── animations.css           # Animation definitions
│   │   └── three-overrides.css      # Three.js canvas styling
│   │
│   ├── utils/
│   │   ├── easing.ts                # Custom easing functions
│   │   ├── colors.ts                # Color system
│   │   ├── animation-presets.ts     # Framer Motion presets
│   │   └── responsive.ts            # Responsive breakpoints
│   │
│   ├── pages/
│   │   ├── index.tsx                # Landing page
│   │   ├── projects.tsx             # Projects/case studies
│   │   └── contact.tsx              # Contact page
│   │
│   └── App.tsx
│
├── public/
│   ├── models/                      # 3D models
│   │   ├── hero-object.glb
│   │   └── data-sphere.glb
│   └── textures/
│       ├── noise.png
│       └── gradients/
│
├── package.json
├── tsconfig.json
├── vite.config.ts
└── tailwind.config.ts
```

---

## DEEL 3: CORE COMPONENTS (Premium quality)

### 3.1 Glassmorphism System

```typescript
// src/components/glass/GlassCard.tsx

import React from 'react';
import { motion } from 'framer-motion';
import styles from './glass.module.css';

interface GlassCardProps {
  children: React.ReactNode;
  intensity?: 'light' | 'medium' | 'strong';  // Blur intensity
  border?: boolean;
  hover?: boolean;
  onClick?: () => void;
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  intensity = 'medium',
  border = true,
  hover = true,
  onClick,
}) => {
  const intensityMap = {
    light: 'blur(10px)',
    medium: 'blur(20px)',
    strong: 'blur(30px)',
  };

  return (
    <motion.div
      className={`${styles.glassCard} ${styles[intensity]} ${border ? styles.border : ''}`}
      style={{
        backdropFilter: intensityMap[intensity],
        WebkitBackdropFilter: intensityMap[intensity],
      }}
      whileHover={hover ? { y: -4, boxShadow: '0 20px 60px rgba(0,0,0,0.3)' } : {}}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      onClick={onClick}
    >
      {children}
    </motion.div>
  );
};
```

```css
/* src/components/glass/glass.css */

.glassCard {
  background: rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  padding: 24px;
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  
  /* Subtle border for definition */
  border: 1px solid rgba(255, 255, 255, 0.2);
  
  /* Layered shadows for depth */
  box-shadow: 
    0 8px 32px rgba(0, 0, 0, 0.1),
    inset 0 0 0 1px rgba(255, 255, 255, 0.1);
  
  /* Performance: will-change for animations */
  will-change: transform, box-shadow;
  
  /* Subtle grain texture overlay */
  position: relative;
}

.glassCard::before {
  content: '';
  position: absolute;
  inset: 0;
  background: 
    url('data:image/svg+xml...');  /* Subtle noise */
  pointer-events: none;
  border-radius: 12px;
  opacity: 0.05;
}

/* Intensity levels */
.glassCard.light {
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.2);
}

.glassCard.strong {
  backdrop-filter: blur(30px);
  -webkit-backdrop-filter: blur(30px);
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.15);
}

/* Border variant */
.glassCard.border {
  border: 2px solid rgba(255, 255, 255, 0.3);
}
```

---

### 3.2 Framer Motion Animation System

```typescript
// src/utils/animation-presets.ts

import { Variants, Transition } from 'framer-motion';

// ===== CONTAINER ANIMATIONS =====
export const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
      type: 'spring',
      damping: 20,
      stiffness: 100,
    },
  },
};

// ===== ITEM ANIMATIONS =====

// Text reveal (letter by letter)
export const letterVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: 'spring',
      damping: 12,
      stiffness: 200,
    },
  },
};

// Slide + fade
export const slideUpVariants: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: [0.23, 1, 0.320, 1], // Custom easing
    },
  },
};

// Stagger from sides
export const slideInFromLeftVariants: Variants = {
  hidden: { opacity: 0, x: -60 },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      ease: 'easeOut',
    },
  },
};

export const slideInFromRightVariants: Variants = {
  hidden: { opacity: 0, x: 60 },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      ease: 'easeOut',
    },
  },
};

// Scale + fade
export const scaleInVariants: Variants = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      type: 'spring',
      damping: 15,
      stiffness: 100,
    },
  },
};

// Rotate + scale
export const rotateInVariants: Variants = {
  hidden: { opacity: 0, scale: 0.5, rotate: -20 },
  visible: {
    opacity: 1,
    scale: 1,
    rotate: 0,
    transition: {
      duration: 0.6,
      ease: 'easeOut',
    },
  },
};

// ===== SCROLL ANIMATIONS =====

// Reveal on scroll
export const scrollRevealVariants: Variants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.7,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
};

// Parallax + fade
export const parallaxVariants = (offset = 0.1) => ({
  hidden: { opacity: 0, y: 100 },
  visible: (custom: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      delay: custom * 0.1,
    },
  }),
});

// ===== HOVER ANIMATIONS =====

export const hoverLiftVariants: Variants = {
  rest: { y: 0 },
  hover: {
    y: -8,
    boxShadow: '0 20px 40px rgba(0,0,0,0.15)',
    transition: { duration: 0.3, ease: 'easeOut' },
  },
};

export const hoverScaleVariants: Variants = {
  rest: { scale: 1 },
  hover: {
    scale: 1.05,
    transition: { duration: 0.3, ease: 'easeOut' },
  },
};

// ===== CUSTOM EASING =====

export const customEasings = {
  smooth: [0.25, 0.46, 0.45, 0.94],
  bounce: [0.68, -0.55, 0.265, 1.55],
  elastic: [0.175, 0.885, 0.32, 1.275],
  sharp: [0.7, 0, 0.84, 0],
};
```

```typescript
// src/components/motion/AnimatedText.tsx

import { motion } from 'framer-motion';
import { letterVariants, containerVariants } from '@/utils/animation-presets';

interface AnimatedTextProps {
  text: string;
  className?: string;
  delay?: number;
  stagger?: number;
}

export const AnimatedText: React.FC<AnimatedTextProps> = ({
  text,
  className,
  delay = 0,
  stagger = 0.05,
}) => {
  const letters = text.split('');

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '-100px' }}
      className="inline"
    >
      {letters.map((letter, i) => (
        <motion.span
          key={`${letter}-${i}`}
          variants={letterVariants}
          className={className}
          style={{
            display: 'inline-block',
            marginRight: letter === ' ' ? '0.25em' : '0',
          }}
        >
          {letter}
        </motion.span>
      ))}
    </motion.div>
  );
};
```

---

### 3.3 Three.js 3D Scene System

```typescript
// src/3d/scenes/HeroScene.tsx

import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { useMouseParallax } from '@/hooks/useMouseParallax';

export const HeroScene: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const objectRef = useRef<THREE.Object3D | null>(null);

  const { mouseX, mouseY } = useMouseParallax();

  useEffect(() => {
    if (!containerRef.current) return;

    // ===== SCENE SETUP =====
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 5;
    cameraRef.current = camera;

    // ===== RENDERER =====
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      devicePixelRatio: Math.min(window.devicePixelRatio, 2),
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    renderer.shadowMap.enabled = true;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // ===== LIGHTS =====
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 10, 7);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    scene.add(directionalLight);

    // ===== CUSTOM 3D OBJECT =====
    // Example: Rotating icosahedron with glow
    const geometry = new THREE.IcosahedronGeometry(2, 4);
    const material = new THREE.MeshStandardMaterial({
      color: 0xff6b35, // Recruitin orange
      metalness: 0.7,
      roughness: 0.2,
      emissive: 0xff6b35,
      emissiveIntensity: 0.5,
    });

    const mesh = new THREE.Mesh(geometry, material);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    objectRef.current = mesh;

    // ===== PARTICLE FIELD =====
    const particleCount = 100;
    const particleGeometry = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 20;
      particlePositions[i + 1] = (Math.random() - 0.5) * 20;
      particlePositions[i + 2] = (Math.random() - 0.5) * 20;
    }

    particleGeometry.setAttribute(
      'position',
      new THREE.BufferAttribute(particlePositions, 3)
    );

    const particleMaterial = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.1,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.5,
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    // ===== ANIMATION LOOP =====
    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);

      if (objectRef.current) {
        // Rotate based on mouse position
        objectRef.current.rotation.x += (mouseY - objectRef.current.rotation.x) * 0.05;
        objectRef.current.rotation.y += (mouseX - objectRef.current.rotation.y) * 0.05;

        // Subtle oscillation
        objectRef.current.position.y = Math.sin(Date.now() * 0.0005) * 0.5;
      }

      if (particles) {
        particles.rotation.x += 0.0001;
        particles.rotation.y += 0.0002;
      }

      renderer.render(scene, camera);
    };

    animate();

    // ===== WINDOW RESIZE =====
    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;

      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
      containerRef.current?.removeChild(renderer.domElement);
      geometry.dispose();
      material.dispose();
      particleGeometry.dispose();
      particleMaterial.dispose();
      renderer.dispose();
    };
  }, [mouseX, mouseY]);

  return (
    <div
      ref={containerRef}
      style={{
        width: '100%',
        height: '100%',
        position: 'absolute',
        top: 0,
        left: 0,
      }}
    />
  );
};
```

```typescript
// src/hooks/useMouseParallax.ts

import { useEffect, useState } from 'react';

export const useMouseParallax = () => {
  const [mouseX, setMouseX] = useState(0);
  const [mouseY, setMouseY] = useState(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMouseX((e.clientX / window.innerWidth) * 2 - 1);
      setMouseY(-(e.clientY / window.innerHeight) * 2 + 1);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return { mouseX, mouseY };
};
```

---

### 3.4 Premium Hero Component

```typescript
// src/components/hero/HeroSection.tsx

import React from 'react';
import { motion } from 'framer-motion';
import { HeroScene } from '@/3d/scenes/HeroScene';
import { GlassCard } from '@/components/glass/GlassCard';
import { AnimatedText } from '@/components/motion/AnimatedText';
import { slideUpVariants, containerVariants } from '@/utils/animation-presets';

export const HeroSection: React.FC = () => {
  return (
    <section className="relative w-full h-screen overflow-hidden bg-black">
      {/* 3D Background */}
      <HeroScene />

      {/* Glass overlay content */}
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="max-w-2xl mx-auto text-center px-6"
        >
          {/* Main headline with animated text */}
          <motion.h1
            variants={slideUpVariants}
            className="text-6xl md:text-7xl font-bold text-white mb-6 leading-tight"
          >
            <AnimatedText
              text="Senior Monteur Almere"
              className="block"
            />
          </motion.h1>

          {/* Subheading */}
          <motion.p
            variants={slideUpVariants}
            className="text-xl md:text-2xl text-gray-300 mb-8 font-light"
          >
            Werktuigbouw | Techniek | Groei
          </motion.p>

          {/* Glass card CTA */}
          <motion.div
            variants={slideUpVariants}
            whileHover={{ scale: 1.05 }}
            className="inline-block"
          >
            <GlassCard intensity="strong" hover>
              <button className="px-8 py-4 text-lg font-semibold text-white hover:text-orange-400 transition-colors">
                Solliciteer nu
              </button>
            </GlassCard>
          </motion.div>

          {/* Decorative stats */}
          <motion.div
            variants={containerVariants}
            className="mt-16 grid grid-cols-3 gap-4"
          >
            {[
              { label: 'Vacatures', value: '12+' },
              { label: 'Bedrijven', value: '500+' },
              { label: 'Plaatsingen', value: '1000+' },
            ].map((stat, i) => (
              <motion.div
                key={i}
                variants={slideUpVariants}
              >
                <GlassCard intensity="light">
                  <p className="text-2xl font-bold text-orange-400">{stat.value}</p>
                  <p className="text-xs text-gray-400">{stat.label}</p>
                </GlassCard>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20"
      >
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <motion.div
            animate={{ y: [0, 8] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-1 h-2 bg-white rounded-full mt-1"
          />
        </div>
      </motion.div>
    </section>
  );
};
```

---

## DEEL 4: CLAUDE CODE PROMPTS (Premium tier)

### Main Agent Prompt

```
You are the Premium Website Architecture Agent for Recruitin B.V.

MISSION: Create extraordinary websites with:
✓ Framer Motion animations (advanced, not generic)
✓ Glassmorphism design system
✓ Three.js 3D hero scenes
✓ Custom easing functions
✓ Scroll-triggered reveals
✓ Mouse parallax effects
✓ WebGL rendering

TECHNOLOGY STACK:
- React 18 + TypeScript
- Framer Motion 11.x
- Three.js R128
- Tailwind CSS 4
- Vite + Vercel

YOUR WORKFLOW:

1. UNDERSTAND PROJECT
   - Sector (Oil&Gas, Construction, etc.)
   - Audience profile
   - Campaign message
   - Brand colors
   
2. DESIGN 3D SCENE
   - Create unique Three.js scene
   - Design mouse parallax interaction
   - Add particle field or custom geometry
   - Plan lighting and materials
   
3. BUILD GLASS COMPONENT SYSTEM
   - Define glass intensity levels
   - Create hover interactions
   - Add subtle textures/grain
   - Plan color overlays
   
4. DESIGN ANIMATIONS
   - Letter-by-letter text reveals
   - Scroll-triggered sections
   - Hover lift effects
   - Staggered container animations
   - Custom easing curves
   
5. IMPLEMENT COMPONENTS
   - Create modular components
   - Use animation presets
   - Add TypeScript types
   - Optimize performance
   
6. QUALITY CHECKLIST
   - Animations smooth (60fps)
   - 3D scene responsive
   - Glass effects performant
   - Mobile-optimized
   - Accessibility maintained

CRITICAL RULES:
✗ Never use Tailwind templates
✗ Never skip 3D scene planning
✗ Never use default easing
✓ Always create custom animation presets
✓ Always plan 3D interactions
✓ Always optimize for performance

When user says "build premium website":
1. Ask about sector + audience
2. Ask about 3D scene preference
3. Ask about animation intensity
4. Ask about glass effect type
5. Generate complete component system
6. Build project structure
7. Deploy to Vercel
```

### Design 3D Scene Prompt

```
You are the 3D Scene Designer using Three.js.

TASK: Create unique 3D hero scene for recruitment campaign

INPUT: {sector}, {audience}, {brand_colors}

DESIGN PROCESS:

1. GEOMETRY SELECTION
   Pick unique base geometry:
   - IcosahedronGeometry (complex, organic)
   - TorusKnotGeometry (flowing, technical)
   - CustomBufferGeometry (bespoke)
   
   ✗ Avoid: basic cubes, spheres, simple objects

2. MATERIAL DESIGN
   - Use MeshStandardMaterial (PBR)
   - Add metalness + roughness variation
   - Use emissive for glow
   - Add envMapIntensity for realism
   
3. LIGHTING STRATEGY
   - Directional light for shadows
   - Ambient light for balance
   - Point lights for accent
   - HDR environment map (optional)
   
4. INTERACTION DESIGN
   - Mouse parallax rotation
   - Sine wave oscillation
   - Particle field animation
   - Camera zoom on scroll
   
5. PERFORMANCE OPTIMIZATION
   - Limit shadow map resolution
   - Use devicePixelRatio clamping
   - Implement LOD (level of detail)
   - Use requestAnimationFrame loop

IMPLEMENT:
- Full Three.js setup code
- Custom geometry creation
- Particle system
- Mouse tracking
- Window resize handler
- Disposal/cleanup

AVOID:
✗ Basic tutorial scenes
✗ Overcomplex models
✗ Poor performance patterns
✗ No responsiveness

OUTPUT: Production-ready HeroScene.tsx component
```

### Animation Presets Prompt

```
You are the Animation Engineer for Framer Motion.

TASK: Create premium animation preset library

REQUIREMENTS:

1. ENTRANCE ANIMATIONS
   - slideUpVariants (with stagger)
   - scaleInVariants (spring physics)
   - rotateInVariants (with rotation)
   - fadeInVariants (subtle)
   
2. SCROLL ANIMATIONS
   - scrollRevealVariants (on scroll trigger)
   - parallaxVariants (offset animation)
   - stickyScrollVariants (fixed items)
   
3. HOVER ANIMATIONS
   - hoverLiftVariants (y offset + shadow)
   - hoverScaleVariants (scale + perspective)
   - hoverGlowVariants (glow effect)
   
4. TEXT ANIMATIONS
   - letterByLetterVariants (character stagger)
   - wordByWordVariants (word stagger)
   - lineByLineVariants (line reveal)
   
5. CUSTOM EASING
   - smooth: [0.25, 0.46, 0.45, 0.94]
   - bounce: [0.68, -0.55, 0.265, 1.55]
   - elastic: [0.175, 0.885, 0.32, 1.275]
   - sharp: [0.7, 0, 0.84, 0]
   
6. CONTAINER ANIMATIONS
   - containerVariants (stagger children)
   - gridVariants (stagger grid items)
   - listVariants (list item animation)

IMPLEMENT:
- Type-safe Variants
- Configurable timing
- Reusable presets
- Performance optimized

OUTPUT: animation-presets.ts with all variants
```

### Glassmorphism System Prompt

```
You are the Glassmorphism Design System Engineer.

TASK: Create premium glass effect component library

COMPONENTS:

1. GlassCard (base component)
   - Intensity levels: light, medium, strong
   - Border variant option
   - Hover animations
   - Grain texture overlay
   
2. GlassNav (navigation)
   - Sticky positioning
   - Blur backdrop
   - Logo placement
   - Menu animation
   
3. GlassButton (interactive)
   - Hover lift effect
   - Click animation
   - Icon support
   - Disabled state
   
4. GlassForm (input elements)
   - Glassmorphic inputs
   - Label animation
   - Focus states
   - Error handling
   
STYLE REQUIREMENTS:

1. COLORS
   - Base: rgba(255, 255, 255, 0.15)
   - Light: rgba(255, 255, 255, 0.2)
   - Strong: rgba(255, 255, 255, 0.1)
   - Border: rgba(255, 255, 255, 0.2-0.3)
   
2. EFFECTS
   - Backdrop blur (10-30px)
   - Subtle borders
   - Layered shadows
   - Inset highlights
   - Grain texture (optional)
   
3. PERFORMANCE
   - will-change optimization
   - Hardware acceleration
   - GPU rendering
   - Mobile-optimized
   
OUTPUT: Complete glassmorphism component system
```

---

## DEEL 5: DEPLOYMENT SETUP (Vercel)

```bash
# 1. Create Vercel project
vercel

# 2. Configure environment
echo "VITE_API_URL=https://api.yourdomain.com" > .env.local

# 3. Deploy
vercel --prod

# 4. Performance monitoring
# Use Vercel Analytics + Web Vitals
```

---

## DEEL 6: QUICK START

### Clone Template
```bash
git clone https://github.com/your-org/premium-websites
cd premium-websites

npm install
npm run dev
```

### First Project
```
In Claude Code:

"Build premium website for Heijmans Senior Uitvoerder Wegen
- Sector: Construction/Wegen
- Audience: Project managers, 40-55 years old
- Brand: Geel #FFC500, Navy #003A70, Rood #E31C23
- 3D Scene: Rotating construction site visualization
- Glass Effect: Strong blur, red accent borders
- Animations: Staggered text reveals, scroll parallax
- Include video section with Kling video"

Claude Code will:
1. Design 3D scene (construction theme)
2. Create animation presets
3. Build glass component system
4. Implement all sections
5. Deploy to Vercel
```

---

## DEEL 7: PERFORMANCE TARGETS

```
Lighthouse Scores:
- Performance: 95+
- Accessibility: 98+
- Best Practices: 100
- SEO: 100

Core Web Vitals:
- LCP (Largest Contentful Paint): <1.5s
- FID (First Input Delay): <50ms
- CLS (Cumulative Layout Shift): <0.05

3D Performance:
- Frame rate: 60 FPS consistent
- GPU utilization: <80%
- Memory: <100MB
```

---

## DEEL 8: TROUBLESHOOTING

### 3D Scene not rendering
```
Check:
1. Canvas size correct?
2. Renderer created?
3. Camera positioned correctly?
4. Lights added to scene?
5. Check console for THREE errors
```

### Glassmorphism blurry on mobile
```
Solutions:
1. Reduce blur intensity on mobile
2. Use CSS media queries
3. Test on actual devices
4. Check backdrop-filter support
```

### Animations janky
```
Check:
1. Will-change applied?
2. No layout shifts during animation?
3. GPU acceleration enabled?
4. Reducer number of animations?
5. Use requestAnimationFrame?
```

---

## DEEL 9: RESOURCES

```
Documentation:
- Framer Motion: https://www.framer.com/motion/
- Three.js: https://threejs.org/docs/
- Tailwind CSS: https://tailwindcss.com/docs
- TypeScript: https://www.typescriptlang.org/docs/

Performance:
- Web Vitals: https://web.dev/vitals/
- Lighthouse: https://developer.chrome.com/docs/lighthouse/
- Vercel Analytics: https://vercel.com/analytics

Community:
- r/webdev
- Framer Slack community
- Three.js Discord
```

---

## DEEL 10: NEXT STEPS

1. **Set up directory structure** in Claude Code
2. **Create animation presets** (copy from above)
3. **Build glassmorphism library** (copy from above)
4. **Design first 3D scene** for your sector
5. **Build hero component** with all pieces
6. **Deploy to Vercel**
7. **Iterate based on performance metrics**

Dit is je premium foundation. 🚀
