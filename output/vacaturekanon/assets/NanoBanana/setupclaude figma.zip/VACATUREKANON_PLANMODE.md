# 🏗️ VACATUREKANON PLANMODE
**Enterprise design templates + framework voor bulk volume generatie**

---

## FASE 1: SITUATIE ANALYSE

### Current State (probleem)

```
Huidige werkflow:
├─ Vacancy input (Pipedrive, Jotform)
├─ Handmatige landing page build
├─ Duplicate/template design patterns
├─ Inconsistent branding
├─ Slow time-to-market
└─ Error-prone (salaris vergeten, wrong CTA, etc.)

Current output:
- 1 vacature = 2-3 uur handmatig werk
- 100 vacatures/maand = 200-300 uur wasted labor
- No A/B testing capability
- No performance tracking per template
```

### Target State (gewenst)

```
Automated workflow:
1. Vacancy data input (Pipedrive/Jotform)
   ↓
2. Sector + audience detection (AI)
   ↓
3. Design template selection (auto)
   ↓
4. Content generation (Claude API)
   ↓
5. Design system applied (CSS tokens)
   ↓
6. Tracking setup (GA4 + Pixel)
   ↓
7. Deploy (Netlify/Vercel)
   ↓
8. Monitor + A/B test
   ↓
Result: 1 vacature = 2-3 MINUTEN
        100 vacatures/maand = 3-5 uur (fully automated)
```

---

## FASE 2: PLANTECHNOLOGIE

### Tech Stack Kaart

```
INPUT LAYER:
├─ Pipedrive (vacancy data)
├─ Jotform (vacancy intake form)
├─ Google Sheets (master config)
└─ CSV export (batch upload)

PROCESSING LAYER:
├─ Zapier (trigger workflows)
├─ Claude API (content generation)
├─ Design token system (Figma)
└─ Asset library (Canva/Leonardo)

GENERATION LAYER:
├─ Template engine (Handlebars/Nunjucks)
├─ CSS-in-JS (Tailwind + custom tokens)
├─ React components (reusable)
└─ Static HTML output

DEPLOYMENT LAYER:
├─ Netlify (primary, bulk deploy via API)
├─ Vercel (alternative, serverless functions)
└─ CloudFlare (CDN + edge cases)

MONITORING LAYER:
├─ Google Analytics 4 (event tracking)
├─ Facebook Pixel (conversion tracking)
├─ Sentry (error tracking)
└─ Custom dashboard (Metabase/Superset)
```

### Architecture Diagram

```
Pipedrive Vacancy
    ↓
┌─────────────────────────────────┐
│   VACANCY ANALYZER AGENT        │
│   (Claude Code)                 │
│                                 │
│  Input: Vacancy JSON            │
│  - Detect sector                │
│  - Analyze audience             │
│  - Recommend template           │
│  - Extract key data             │
│                                 │
│  Output: Metadata + specs       │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│   DESIGN TEMPLATE SELECTOR      │
│   (Rule engine)                 │
│                                 │
│  If sector = "construction"     │
│    → Use "BlueCollar Template"  │
│  Else if sector = "IT"          │
│    → Use "TechTemplate"         │
│  Else if audience = "40+"       │
│    → Use "Professional"         │
│                                 │
│  Output: Template ID + config   │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│   CONTENT GENERATOR AGENT       │
│   (Claude API)                  │
│                                 │
│  Input: Vacancy data + template │
│  - Generate headlines           │
│  - Write benefits section       │
│  - Create testimonial prompts   │
│  - Design CTA copy              │
│                                 │
│  Output: Content JSON           │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│   DESIGN SYSTEM APPLIER         │
│   (CSS token injector)          │
│                                 │
│  Input: Template + content      │
│  - Apply brand colors           │
│  - Set typography               │
│  - Configure spacing            │
│  - Inject animations            │
│                                 │
│  Output: Styled HTML            │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│   ASSET GENERATOR               │
│   (Canva/Leonardo MCP)          │
│                                 │
│  Input: Vacancy + design specs  │
│  - Generate hero image          │
│  - Create social cards          │
│  - Design banner variations     │
│                                 │
│  Output: Image URLs             │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│   PAGE COMPILER                 │
│   (Nunjucks/Handlebars)         │
│                                 │
│  Input: All pieces above        │
│  - Render final HTML            │
│  - Inject tracking codes        │
│  - Optimize for performance     │
│                                 │
│  Output: Production HTML        │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│   DEPLOY ENGINE                 │
│   (Netlify/Vercel API)          │
│                                 │
│  Input: HTML + domain config    │
│  - Create site on Netlify       │
│  - Setup custom domain (optional)
│  - Configure redirects          │
│  - Enable analytics             │
│                                 │
│  Output: Live URL               │
└─────────────────────────────────┘
    ↓
Live Landing Page
```

---

## FASE 3: DESIGN TEMPLATE LIBRARY

### Template Kategorisatie

```
TIER 1: SECTOR-BASED
├─ BlueCollar (Technisch MBO)
│   ├─ Servicemonteur
│   ├─ Elektromonteur
│   ├─ Lasser
│   └─ Chauffeur
│
├─ Construction (Civiel/Bouw)
│   ├─ Senior Monteur
│   ├─ Projectleider
│   └─ Uitvoerder
│
├─ IT/Tech
│   ├─ DevOps Engineer
│   ├─ Full Stack Dev
│   └─ Cloud Architect
│
├─ Industrial (Oil&Gas/Manufacturing)
│   ├─ Process Engineer
│   ├─ Maintenance Tech
│   └─ Safety Inspector
│
└─ Finance (Accountancy/Banking)
    ├─ Belastingadviseur
    └─ Accountant

TIER 2: AUDIENCE-BASED
├─ JuniorAudience (18-28 years)
├─ MidCareer (28-45 years)
└─ SeniorAudience (45+ years)

TIER 3: FORMAT-BASED
├─ WhatsApp-First (blauwboord)
├─ LinkedIn-First (professionals)
├─ Email-First (finance)
└─ Multi-Channel (hybrid)

TIER 4: FEATURE-BASED
├─ MinimalTemplate (3-4 sections)
├─ StandardTemplate (7-8 sections)
└─ PremiumTemplate (12+ sections)
```

### Template Spec Definition

```python
# Template structure (JSON schema)

{
  "id": "bluecollar-v2.1",
  "name": "Blue Collar Technician",
  "sector": "construction",
  "audience": "technician",
  "mobile_first": true,
  "primary_cta": "whatsapp",
  "secondary_cta": "email",
  
  "sections": [
    {
      "id": "hero",
      "type": "hero",
      "required_fields": ["title", "salary", "location", "cta_text"],
      "design": {
        "layout": "asymmetric_left",
        "background": "gradient_with_image",
        "text_color": "color-contrast-high",
        "sticky_cta": true
      }
    },
    {
      "id": "job_description",
      "type": "list",
      "required_fields": ["duties"],
      "design": {
        "layout": "bullet_points",
        "columns": 1,
        "accent_icons": true
      }
    },
    {
      "id": "requirements",
      "type": "list",
      "required_fields": ["must_have", "nice_to_have"],
      "design": {
        "layout": "two_column",
        "visual_separation": true
      }
    },
    {
      "id": "benefits",
      "type": "feature_grid",
      "required_fields": ["benefits_list"],
      "design": {
        "layout": "3_column_grid",
        "icons": "colored_circles",
        "card_style": "glass_morphism"
      }
    },
    {
      "id": "company_story",
      "type": "testimonial",
      "required_fields": ["company_description", "testimonial_author", "testimonial_quote"],
      "design": {
        "layout": "quote_with_image",
        "image_position": "left",
        "quote_size": "large"
      }
    },
    {
      "id": "cta_form",
      "type": "form",
      "required_fields": ["form_fields"],
      "design": {
        "fields_count": 3,
        "layout": "stacked",
        "button_style": "prominent",
        "form_position": "bottom"
      }
    }
  ],
  
  "design_tokens": {
    "color_override": null,  # Use client branding
    "typography": "large_readable",
    "spacing_scale": "generous",
    "animations": "subtle",
    "glass_effect": false
  },
  
  "performance_targets": {
    "lighthouse_score": 90,
    "load_time_mobile": 2.5,
    "first_contentful_paint": 1.2
  }
}
```

---

## FASE 4: CORE TEMPLATES (Verbeterd)

### Template 1: BLUE COLLAR (Technisch)

**Bestand: `templates/bluecollar-v2.1.html`**

```html
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{{jobTitle}} - {{companySalary}}</title>
  
  <!-- Design Tokens (dynamic injection) -->
  <style>
    :root {
      --color-primary: {{brandPrimary}};
      --color-accent: {{brandAccent}};
      --color-text: {{brandText}};
      --color-bg: {{brandBg}};
      --company-name: "{{companyName}}";
    }
  </style>
  
  <!-- Base Styles -->
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: var(--color-bg);
      color: var(--color-text);
      line-height: 1.6;
    }
    
    /* HERO SECTION */
    .hero {
      background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-accent) 100%);
      color: white;
      padding: 40px 20px;
      text-align: center;
      position: relative;
      min-height: 60vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .hero-content {
      max-width: 600px;
      z-index: 10;
    }
    
    .hero h1 {
      font-size: 48px;
      font-weight: 700;
      margin-bottom: 20px;
      line-height: 1.1;
    }
    
    .hero-meta {
      font-size: 24px;
      margin: 20px 0;
      font-weight: 600;
    }
    
    .hero-cta {
      background: white;
      color: var(--color-primary);
      border: none;
      padding: 16px 32px;
      font-size: 18px;
      font-weight: 600;
      border-radius: 8px;
      cursor: pointer;
      margin-top: 30px;
      transition: all 200ms ease-out;
    }
    
    .hero-cta:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.2);
    }
    
    /* STICKY CTA (mobile) */
    @media (max-width: 768px) {
      .sticky-cta {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: var(--color-primary);
        padding: 12px;
        z-index: 100;
        box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
      }
      
      .sticky-cta button {
        width: 100%;
        padding: 14px;
        font-size: 16px;
      }
      
      body {
        padding-bottom: 60px;
      }
    }
    
    /* SECTION LAYOUT */
    .section {
      max-width: 900px;
      margin: 0 auto;
      padding: 60px 20px;
      border-bottom: 1px solid #eee;
    }
    
    .section h2 {
      font-size: 32px;
      font-weight: 700;
      margin-bottom: 30px;
      color: var(--color-accent);
    }
    
    /* DUTIES LIST */
    .duties-list {
      display: grid;
      gap: 16px;
    }
    
    .duty-item {
      display: flex;
      gap: 12px;
      padding: 16px;
      background: #f5f5f5;
      border-left: 4px solid var(--color-primary);
      border-radius: 4px;
    }
    
    .duty-item::before {
      content: "✓";
      color: var(--color-primary);
      font-weight: 700;
      font-size: 20px;
      flex-shrink: 0;
    }
    
    /* REQUIREMENTS */
    .requirements {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 32px;
    }
    
    @media (max-width: 768px) {
      .requirements {
        grid-template-columns: 1fr;
      }
    }
    
    .requirement-group h3 {
      color: var(--color-primary);
      margin-bottom: 16px;
      font-size: 18px;
    }
    
    .requirement-item {
      padding: 12px 0;
      border-bottom: 1px solid #eee;
      font-size: 14px;
    }
    
    /* BENEFITS GRID */
    .benefits-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 24px;
    }
    
    .benefit-card {
      padding: 24px;
      background: linear-gradient(135deg, 
        rgba(var(--color-primary-rgb), 0.05) 0%, 
        rgba(var(--color-accent-rgb), 0.05) 100%);
      border-radius: 8px;
      border: 1px solid var(--color-primary);
      text-align: center;
    }
    
    .benefit-icon {
      font-size: 40px;
      margin-bottom: 12px;
    }
    
    .benefit-card h3 {
      color: var(--color-accent);
      margin-bottom: 8px;
      font-size: 16px;
    }
    
    /* TESTIMONIAL */
    .testimonial-section {
      background: var(--color-accent);
      color: white;
      padding: 60px 20px;
    }
    
    .testimonial-content {
      max-width: 800px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 40px;
      align-items: center;
    }
    
    @media (max-width: 768px) {
      .testimonial-content {
        grid-template-columns: 1fr;
      }
    }
    
    .testimonial-quote {
      font-size: 24px;
      font-weight: 600;
      line-height: 1.4;
      border-left: 4px solid white;
      padding-left: 20px;
    }
    
    .testimonial-author {
      margin-top: 16px;
      font-size: 14px;
      opacity: 0.9;
    }
    
    .testimonial-image {
      width: 100%;
      border-radius: 8px;
      object-fit: cover;
    }
    
    /* FORM */
    .form-section {
      max-width: 500px;
      margin: 0 auto;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 8px;
      font-weight: 500;
      color: var(--color-accent);
    }
    
    .form-group input {
      width: 100%;
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 16px;
      font-family: inherit;
    }
    
    .form-submit {
      background: var(--color-primary);
      color: white;
      border: none;
      padding: 14px 32px;
      font-size: 16px;
      font-weight: 600;
      border-radius: 4px;
      cursor: pointer;
      width: 100%;
      transition: all 200ms ease-out;
    }
    
    .form-submit:hover {
      background: var(--color-accent);
      transform: translateY(-2px);
    }
    
    /* PERFORMANCE: Lazy loading */
    img {
      loading: lazy;
    }
    
    /* Animations */
    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .section {
      animation: slideUp 600ms ease-out forwards;
    }
  </style>
</head>
<body>
  <!-- TRACKING -->
  <script>
    <!-- Facebook Pixel -->
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '{{pixelId}}');
    fbq('track', 'PageView');
    
    <!-- GA4 -->
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '{{ga4Id}}');
  </script>

  <!-- HERO SECTION -->
  <section class="hero">
    <div class="hero-content">
      <h1>{{jobTitle}}</h1>
      <div class="hero-meta">
        {{salary}} • {{location}}
      </div>
      <button class="hero-cta" onclick="scrollToForm()">
        {{ctaText}}
      </button>
    </div>
  </section>

  <!-- JOB DUTIES -->
  <section class="section">
    <h2>Wat je gaat doen</h2>
    <div class="duties-list">
      {{#each duties}}
      <div class="duty-item">{{this}}</div>
      {{/each}}
    </div>
  </section>

  <!-- REQUIREMENTS -->
  <section class="section">
    <h2>Wie we zoeken</h2>
    <div class="requirements">
      <div class="requirement-group">
        <h3>Must-have</h3>
        {{#each mustHave}}
        <div class="requirement-item">{{this}}</div>
        {{/each}}
      </div>
      <div class="requirement-group">
        <h3>Nice-to-have</h3>
        {{#each niceToHave}}
        <div class="requirement-item">{{this}}</div>
        {{/each}}
      </div>
    </div>
  </section>

  <!-- BENEFITS -->
  <section class="section">
    <h2>Wat we bieden</h2>
    <div class="benefits-grid">
      {{#each benefits}}
      <div class="benefit-card">
        <div class="benefit-icon">{{icon}}</div>
        <h3>{{title}}</h3>
        <p>{{description}}</p>
      </div>
      {{/each}}
    </div>
  </section>

  <!-- TESTIMONIAL -->
  <section class="testimonial-section">
    <div class="testimonial-content">
      <div>
        <div class="testimonial-quote">"{{testimonialQuote}}"</div>
        <div class="testimonial-author">— {{testimonialAuthor}}, {{testimonialRole}}</div>
      </div>
      <img src="{{testimonialImage}}" alt="{{testimonialAuthor}}" class="testimonial-image">
    </div>
  </section>

  <!-- FORM -->
  <section class="section form-section" id="form-section">
    <h2>Solliciteer nu</h2>
    <form onsubmit="handleSubmit(event)">
      <div class="form-group">
        <label>Naam</label>
        <input type="text" name="name" required>
      </div>
      <div class="form-group">
        <label>Telefoonnummer</label>
        <input type="tel" name="phone" required>
      </div>
      <div class="form-group">
        <label>Bericht (optioneel)</label>
        <textarea name="message" rows="4"></textarea>
      </div>
      <button type="submit" class="form-submit">Verstuur</button>
    </form>
  </section>

  <!-- STICKY CTA (mobile) -->
  <div class="sticky-cta">
    <button onclick="document.getElementById('whatsapp-link').click()" class="hero-cta">
      WhatsApp →
    </button>
    <a id="whatsapp-link" href="https://wa.me/{{phone}}" style="display:none;"></a>
  </div>

  <!-- SCRIPTS -->
  <script>
    function scrollToForm() {
      document.getElementById('form-section').scrollIntoView({ behavior: 'smooth' });
    }
    
    function handleSubmit(event) {
      event.preventDefault();
      fbq('track', 'Lead', { content_name: 'Form Submit' });
      gtag('event', 'form_submit', { vacancy_id: '{{vacancyId}}' });
      // Send to backend
    }
  </script>
</body>
</html>
```

---

## FASE 5: GENERATION ENGINE

### Template Compiler (Nunjucks/Handlebars)

**Bestand: `generators/template-engine.js`**

```javascript
/**
 * VACATUREKANON TEMPLATE ENGINE
 * Compiles templates with design tokens + content
 */

const Nunjucks = require('nunjucks');
const fs = require('fs');
const path = require('path');

class VacancyTemplateEngine {
  constructor(templateDir = './templates') {
    this.templateDir = templateDir;
    this.env = new Nunjucks.Environment(
      new Nunjucks.FileSystemLoader(templateDir)
    );
  }

  /**
   * Compile single vacancy into HTML
   */
  async compile(vacancyData, templateId = 'bluecollar-v2.1') {
    try {
      // 1. Load template
      const template = this.env.getTemplate(`${templateId}.html`);
      
      // 2. Prepare data
      const compiledData = await this.prepareData(vacancyData);
      
      // 3. Render
      const html = template.render(compiledData);
      
      // 4. Optimize (minify, critical CSS, etc.)
      const optimized = await this.optimize(html);
      
      return optimized;
    } catch (error) {
      console.error(`Template compile error: ${error.message}`);
      throw error;
    }
  }

  /**
   * Prepare and validate vacancy data
   */
  async prepareData(vacancy) {
    const defaults = {
      jobTitle: 'Position Title',
      salary: 'Negotiable',
      location: 'Netherlands',
      duties: [],
      mustHave: [],
      niceToHave: [],
      benefits: [],
      testimonialQuote: 'Great opportunity!',
      testimonialAuthor: 'John Doe',
      testimonialRole: 'Team Lead',
    };

    // Merge with defaults
    const data = { ...defaults, ...vacancy };

    // Enrich with generated content if needed
    if (!data.testimonialImage) {
      data.testimonialImage = await this.generateDefaultImage(
        data.jobTitle,
        data.companySalary
      );
    }

    return data;
  }

  /**
   * Generate fallback image via Leonardo/Canva
   */
  async generateDefaultImage(jobTitle, salary) {
    // Placeholder: In production, call Leonardo AI or Canva API
    return 'https://via.placeholder.com/400x300?text=Team+Photo';
  }

  /**
   * Optimize HTML for production
   */
  async optimize(html) {
    // 1. Inline critical CSS
    // 2. Defer non-critical resources
    // 3. Minify
    // 4. Add performance hints
    
    return html
      .replace(/\n\s+/g, ' ')  // Remove whitespace
      .replace(/>\s+</g, '><'); // Remove space between tags
  }

  /**
   * Bulk compile multiple vacancies
   */
  async compileBulk(vacancies, templateId = 'bluecollar-v2.1') {
    const results = [];
    
    for (const vacancy of vacancies) {
      try {
        const html = await this.compile(vacancy, templateId);
        results.push({
          vacancyId: vacancy.id,
          success: true,
          html,
        });
      } catch (error) {
        results.push({
          vacancyId: vacancy.id,
          success: false,
          error: error.message,
        });
      }
    }
    
    return results;
  }
}

module.exports = VacancyTemplateEngine;
```

---

## FASE 6: DEPLOYMENT PIPELINE

### Bulk Deploy Script

**Bestand: `deploy/netlify-bulk-deploy.js`**

```javascript
/**
 * NETLIFY BULK DEPLOY
 * Deploy 100+ sites in parallel
 */

const fetch = require('node-fetch');
const fs = require('fs');

class NetlifyBulkDeployer {
  constructor(accessToken) {
    this.accessToken = accessToken;
    this.apiBase = 'https://api.netlify.com/api/v1';
  }

  /**
   * Deploy single site
   */
  async deploySite(siteData) {
    const { vacancyId, vacancyTitle, html, customDomain } = siteData;

    try {
      // 1. Create site if not exists
      let siteId = await this.getOrCreateSite(vacancyId, vacancyTitle);

      // 2. Deploy HTML
      const deploy = await this.uploadDeploy(siteId, html);

      // 3. Configure domain (optional)
      if (customDomain) {
        await this.setupCustomDomain(siteId, customDomain);
      }

      // 4. Setup redirects & headers
      await this.configureNetlifyToml(siteId);

      return {
        vacancyId,
        success: true,
        url: `https://${siteId}.netlify.app`,
        customUrl: customDomain ? `https://${customDomain}` : null,
      };
    } catch (error) {
      return {
        vacancyId,
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Deploy multiple sites in parallel (5 concurrent)
   */
  async deployBulk(sitesToDeploy, concurrency = 5) {
    const results = [];
    
    for (let i = 0; i < sitesToDeploy.length; i += concurrency) {
      const batch = sitesToDeploy.slice(i, i + concurrency);
      const batchResults = await Promise.all(
        batch.map(site => this.deploySite(site))
      );
      results.push(...batchResults);
      
      console.log(`✅ Deployed ${i + concurrency}/${sitesToDeploy.length}`);
    }
    
    return results;
  }

  /**
   * Get or create Netlify site
   */
  async getOrCreateSite(vacancyId, vacancyTitle) {
    const siteName = `vacancy-${vacancyId}`.toLowerCase().replace(/[^a-z0-9-]/g, '-');
    
    // Check if exists
    const existing = await this.getSite(siteName);
    if (existing) return existing.id;
    
    // Create new
    const response = await fetch(`${this.apiBase}/sites`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: siteName,
        repo: null, // No git repo, manual deployment
      }),
    });

    if (!response.ok) throw new Error(`Netlify API: ${response.statusText}`);
    
    const site = await response.json();
    return site.id;
  }

  /**
   * Upload HTML deploy to Netlify
   */
  async uploadDeploy(siteId, html) {
    const response = await fetch(
      `${this.apiBase}/sites/${siteId}/deploys`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.accessToken}`,
          'Content-Type': 'application/zip',
        },
        body: this.htmlToZip(html), // Package HTML as zip
      }
    );

    if (!response.ok) throw new Error(`Netlify deploy failed`);
    return response.json();
  }

  /**
   * Setup redirects & performance headers
   */
  async configureNetlifyToml(siteId) {
    const netlifyConfig = `
[build]
  publish = "public"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[[headers]]
  for = "/*"
  [headers.values]
    Cache-Control = "public, max-age=3600"
    X-Content-Type-Options = "nosniff"
    X-Frame-Options = "SAMEORIGIN"
    X-XSS-Protection = "1; mode=block"
`;

    // Store in Netlify config
    // Implementation depends on Netlify API version
  }
}

module.exports = NetlifyBulkDeployer;
```

---

## FASE 7: ORCHESTRATION AGENT

### Main Orchestrator (Claude Code)

**Bestand: `agents/vacaturekanon-main-agent.py`**

```python
#!/usr/bin/env python3
"""
VACATUREKANON MAIN ORCHESTRATOR
Controls entire bulk landing page generation pipeline
"""

import json
import asyncio
from typing import List, Dict
from datetime import datetime

class VacatureKanonOrchestrator:
    def __init__(self):
        self.stats = {
            "total_vacancies": 0,
            "compiled": 0,
            "deployed": 0,
            "errors": 0,
            "start_time": None,
            "end_time": None,
        }
    
    async def run_pipeline(self, vacancies: List[Dict]):
        """
        Run complete pipeline:
        Input → Analyze → Design → Generate → Deploy → Monitor
        """
        
        self.stats["start_time"] = datetime.now()
        self.stats["total_vacancies"] = len(vacancies)
        
        print("\n" + "="*70)
        print("🚀 VACATUREKANON PIPELINE STARTED")
        print("="*70)
        
        # PHASE 1: Analyze & Categorize
        print("\n📊 PHASE 1: Analyzing vacancies...")
        analyzed = await self.analyze_vacancies(vacancies)
        
        # PHASE 2: Select Templates
        print("\n🎨 PHASE 2: Selecting design templates...")
        templated = await self.select_templates(analyzed)
        
        # PHASE 3: Generate Content
        print("\n✍️  PHASE 3: Generating content...")
        content_rich = await self.generate_content(templated)
        
        # PHASE 4: Apply Design System
        print("\n🎭 PHASE 4: Applying design system...")
        designed = await self.apply_design_system(content_rich)
        
        # PHASE 5: Compile Templates
        print("\n⚙️  PHASE 5: Compiling HTML...")
        compiled = await self.compile_templates(designed)
        
        # PHASE 6: Deploy
        print("\n🌐 PHASE 6: Deploying sites...")
        deployed = await self.deploy_sites(compiled)
        
        # PHASE 7: Verify & Report
        print("\n✅ PHASE 7: Verification & reporting...")
        report = await self.generate_report(deployed)
        
        self.stats["end_time"] = datetime.now()
        
        print("\n" + "="*70)
        print("✨ PIPELINE COMPLETE")
        print("="*70)
        print(f"\nStats:")
        print(f"  Total: {self.stats['total_vacancies']}")
        print(f"  Deployed: {self.stats['deployed']}")
        print(f"  Errors: {self.stats['errors']}")
        print(f"  Duration: {self.get_duration()}")
        print(f"\nReport saved: {report}")
        
        return deployed
    
    async def analyze_vacancies(self, vacancies: List[Dict]):
        """
        Analyze each vacancy:
        - Detect sector
        - Identify audience
        - Recommend template
        """
        
        analyzed = []
        
        for vacancy in vacancies:
            analysis = {
                **vacancy,
                "sector": self.detect_sector(vacancy),
                "audience": self.analyze_audience(vacancy),
                "recommended_template": self.recommend_template(
                    vacancy.get("sector"),
                    vacancy.get("seniority_level")
                ),
            }
            analyzed.append(analysis)
        
        print(f"✅ Analyzed {len(analyzed)} vacancies")
        return analyzed
    
    def detect_sector(self, vacancy: Dict) -> str:
        """Use keywords to detect sector"""
        
        keywords = {
            "construction": ["monteur", "montage", "wegen", "civiel", "bouw"],
            "it": ["developer", "engineer", "devops", "cloud", "python", "java"],
            "industrial": ["process", "technician", "oil", "gas", "maintenance"],
            "finance": ["accountant", "boekhouding", "tax", "advisory"],
        }
        
        title = vacancy.get("job_title", "").lower()
        
        for sector, keywords_list in keywords.items():
            if any(kw in title for kw in keywords_list):
                return sector
        
        return "general"
    
    def analyze_audience(self, vacancy: Dict) -> Dict:
        """Analyze target audience"""
        
        return {
            "education_level": self.guess_education(vacancy),
            "age_range": self.guess_age_range(vacancy),
            "platform_preference": self.guess_platform(vacancy),
            "language": vacancy.get("language", "nl"),
        }
    
    def recommend_template(self, sector: str, seniority: str) -> str:
        """Recommend best template"""
        
        template_map = {
            "construction": "bluecollar-v2.1",
            "it": "tech-premium-v1.0",
            "industrial": "industrial-v1.0",
            "finance": "professional-v1.0",
        }
        
        return template_map.get(sector, "standard-v1.0")
    
    async def select_templates(self, vacancies: List[Dict]):
        """
        Select template for each vacancy
        """
        # Implementation
        return vacancies
    
    async def generate_content(self, vacancies: List[Dict]):
        """
        Use Claude API to generate content
        """
        # Call Claude for content generation
        # - Headlines
        # - Benefits sections
        # - Testimonial prompts
        # etc.
        return vacancies
    
    async def apply_design_system(self, vacancies: List[Dict]):
        """
        Apply brand colors + design tokens
        """
        # Implementation
        return vacancies
    
    async def compile_templates(self, vacancies: List[Dict]):
        """
        Compile HTML from templates + data
        """
        # Implementation
        return vacancies
    
    async def deploy_sites(self, compiled_sites: List[Dict]):
        """
        Deploy to Netlify in parallel
        """
        # Implementation
        self.stats["deployed"] = len(compiled_sites)
        return compiled_sites
    
    async def generate_report(self, deployed: List[Dict]):
        """
        Generate deployment report
        """
        
        report = {
            "timestamp": datetime.now().isoformat(),
            "stats": self.stats,
            "sites": deployed,
        }
        
        filename = f"vacaturekanon-report-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
        
        with open(filename, "w") as f:
            json.dump(report, f, indent=2)
        
        return filename
    
    def get_duration(self):
        if self.stats["start_time"] and self.stats["end_time"]:
            delta = self.stats["end_time"] - self.stats["start_time"]
            return f"{delta.total_seconds():.1f}s"
        return "N/A"


async def main():
    """Example usage"""
    
    # Load vacancies from Pipedrive/CSV
    vacancies = [
        {
            "id": "vac_001",
            "job_title": "Servicemonteur",
            "company": "Heijmans",
            "salary": "€2.800 - €3.400",
            "location": "Amsterdam",
        },
        # ... more vacancies
    ]
    
    orchestrator = VacatureKanonOrchestrator()
    result = await orchestrator.run_pipeline(vacancies)
    
    # Result: List of deployed sites with URLs


if __name__ == "__main__":
    asyncio.run(main())
```

---

## FASE 8: MONITORING & OPTIMIZATION

### Performance Dashboard Setup

```python
# monitors/vacancy-dashboard.py

class VacancyPerformanceMonitor:
    """
    Track performance per template + vacancy type
    """
    
    def __init__(self):
        self.metrics = {}
    
    def track_vacancy(self, vacancy_id, template_id, metrics):
        """
        Record:
        - Page load time
        - Conversion rate
        - Form submissions
        - Source (Facebook/Google/LinkedIn)
        """
        
        self.metrics[vacancy_id] = {
            "template": template_id,
            "load_time_ms": metrics["load_time"],
            "bounce_rate": metrics["bounce_rate"],
            "conversion_rate": metrics["conversion_rate"],
            "form_submissions": metrics["form_submissions"],
            "whatsapp_clicks": metrics["whatsapp_clicks"],
        }
    
    def get_template_performance(self, template_id):
        """Compare performance by template"""
        
        vacancies = [
            m for m in self.metrics.values()
            if m["template"] == template_id
        ]
        
        return {
            "template": template_id,
            "avg_conversion_rate": sum(v["conversion_rate"] for v in vacancies) / len(vacancies),
            "avg_load_time": sum(v["load_time_ms"] for v in vacancies) / len(vacancies),
            "total_submissions": sum(v["form_submissions"] for v in vacancies),
        }
    
    def recommend_template_improvements(self):
        """A/B testing recommendations"""
        
        # Compare templates
        # Suggest optimizations
        # Flag underperformers
        pass
```

---

## SAMENVATTING PLANMODE

### Current → Target

```
CURRENT STATE:
├─ Handmatig design per vacancy
├─ 2-3 uur per pagina
├─ Inconsistent branding
├─ Limited tracking
└─ ~10-20 pagina's per week

TARGET STATE:
├─ Fully automated pipeline
├─ 2-3 MINUTEN per pagina (100x faster!)
├─ Perfect brand consistency
├─ Comprehensive GA4 + Pixel tracking
├─ 500+ pagina's per week
└─ A/B testing capability
```

### Tech Stack Summary

```
INPUT:        Pipedrive + Jotform + CSV
ANALYSIS:     Claude Code + Python
GENERATION:   Claude API + Handlebars
DESIGN:       CSS tokens + Tailwind
DEPLOY:       Netlify API (bulk)
MONITOR:      GA4 + Sentry + Custom dashboard
```

### Implementation Timeline

```
WEEK 1: Build core framework
  □ Design template library
  □ Setup design token system
  □ Build template engine

WEEK 2: Build generation pipeline
  □ Vacancy analyzer
  □ Content generator (Claude API)
  □ Design system applier

WEEK 3: Deployment & monitoring
  □ Netlify bulk deployer
  □ Analytics dashboard
  □ Error handling

WEEK 4: Optimization & scaling
  □ Performance improvements
  □ A/B testing setup
  □ Auto-optimization agent
```

---

Dit is je complete PLANMODE voor Vacaturekanon 2.0! 🎯

Volgende: Wil je
**A)** Volledige implementatie guide per component?
**B)** Ready-to-use starter templates (copy-paste)?
**C)** Claude Code agents setup voor automation?
