# 🎨 LANDING PAGE SETUP
**Claude Code + Figma - Eenvoudig en direct**

---

## STAP 1: FOLDER STRUCTURE

```bash
mkdir landing-pages
cd landing-pages

# Create structure
mkdir -p src/{components,styles,pages} public templates
```

---

## STAP 2: PACKAGE.JSON

```json
{
  "name": "landing-pages",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "framer-motion": "^11.0.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.0.0",
    "vite": "^4.4.0",
    "tailwindcss": "^3.3.0",
    "postcss": "^8.4.0",
    "autoprefixer": "^10.4.0"
  }
}
```

---

## STAP 3: VITE CONFIG

**vite.config.js**

```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
  },
})
```

---

## STAP 4: TAILWIND CONFIG

**tailwind.config.js**

```javascript
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

---

## STAP 5: BASE STYLES

**src/styles/globals.css**

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  line-height: 1.6;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}
```

---

## STAP 6: BASIC COMPONENTS

### Hero Component

**src/components/Hero.jsx**

```jsx
import { motion } from 'framer-motion';

export const Hero = ({ title, subtitle, cta, image }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 to-blue-700 text-white">
      <div className="container grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            {title}
          </h1>
          <p className="text-xl text-blue-100 mb-8">
            {subtitle}
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            className="bg-white text-blue-900 px-8 py-4 rounded-lg font-semibold text-lg hover:shadow-lg transition-shadow"
          >
            {cta}
          </motion.button>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          {image && <img src={image} alt="Hero" className="rounded-lg shadow-lg" />}
        </motion.div>
      </div>
    </section>
  );
};
```

### Features Component

**src/components/Features.jsx**

```jsx
import { motion } from 'framer-motion';

export const Features = ({ items }) => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container">
        <h2 className="text-4xl font-bold text-center mb-16">Features</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {items.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="text-4xl mb-4">{item.icon}</div>
              <h3 className="text-xl font-bold mb-4">{item.title}</h3>
              <p className="text-gray-600">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
```

### CTA Component

**src/components/CTA.jsx**

```jsx
import { motion } from 'framer-motion';

export const CTA = ({ headline, description, buttonText, buttonLink }) => {
  return (
    <section className="py-20 bg-blue-600 text-white">
      <div className="container text-center">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold mb-6">{headline}</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            {description}
          </p>
          <motion.a
            href={buttonLink}
            whileHover={{ scale: 1.05 }}
            className="inline-block bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:shadow-lg transition-shadow"
          >
            {buttonText}
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};
```

### Form Component

**src/components/Form.jsx**

```jsx
import { useState } from 'react';
import { motion } from 'framer-motion';

export const Form = ({ title, fields, onSubmit }) => {
  const [data, setData] = useState({});

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(data);
    setData({});
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container max-w-lg">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-8 text-center">{title}</h2>
          
          <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-lg">
            {fields.map((field) => (
              <div key={field.name} className="mb-6">
                <label className="block text-gray-700 font-semibold mb-2">
                  {field.label}
                </label>
                {field.type === 'textarea' ? (
                  <textarea
                    name={field.name}
                    value={data[field.name] || ''}
                    onChange={handleChange}
                    placeholder={field.placeholder}
                    rows={field.rows || 4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                ) : (
                  <input
                    type={field.type || 'text'}
                    name={field.name}
                    value={data[field.name] || ''}
                    onChange={handleChange}
                    placeholder={field.placeholder}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                )}
              </div>
            ))}
            
            <motion.button
              whileHover={{ scale: 1.02 }}
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Send
            </motion.button>
          </form>
        </motion.div>
      </div>
    </section>
  );
};
```

---

## STAP 7: LANDING PAGE TEMPLATE

**src/pages/LandingPage.jsx**

```jsx
import { Hero } from '../components/Hero';
import { Features } from '../components/Features';
import { CTA } from '../components/CTA';
import { Form } from '../components/Form';

export const LandingPage = ({ config }) => {
  const handleFormSubmit = (data) => {
    console.log('Form submitted:', data);
    // Send to server/email
  };

  return (
    <div>
      <Hero
        title={config.hero.title}
        subtitle={config.hero.subtitle}
        cta={config.hero.cta}
        image={config.hero.image}
      />

      <Features items={config.features} />

      <CTA
        headline={config.cta.headline}
        description={config.cta.description}
        buttonText={config.cta.buttonText}
        buttonLink={config.cta.buttonLink}
      />

      <Form
        title={config.form.title}
        fields={config.form.fields}
        onSubmit={handleFormSubmit}
      />
    </div>
  );
};
```

---

## STAP 8: APP.JSX

```jsx
import { LandingPage } from './pages/LandingPage';
import './styles/globals.css';

const pageConfig = {
  hero: {
    title: 'Welcome to Our Service',
    subtitle: 'Build amazing things with us',
    cta: 'Get Started',
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=500&h=500&fit=crop',
  },
  features: [
    {
      icon: '🚀',
      title: 'Fast',
      description: 'Lightning quick performance',
    },
    {
      icon: '🔒',
      title: 'Secure',
      description: 'Bank-level security',
    },
    {
      icon: '💻',
      title: 'Easy',
      description: 'Simple to use interface',
    },
  ],
  cta: {
    headline: 'Ready to get started?',
    description: 'Join thousands of satisfied customers today',
    buttonText: 'Sign Up Now',
    buttonLink: '#form',
  },
  form: {
    title: 'Contact Us',
    fields: [
      { name: 'name', label: 'Name', placeholder: 'John Doe' },
      { name: 'email', label: 'Email', type: 'email', placeholder: 'john@example.com' },
      { name: 'message', label: 'Message', type: 'textarea', placeholder: 'Tell us about your project' },
    ],
  },
};

function App() {
  return <LandingPage config={pageConfig} />;
}

export default App;
```

---

## STAP 9: INDEX.HTML

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Landing Page</title>
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/src/main.jsx"></script>
</body>
</html>
```

---

## STAP 10: MAIN.JSX

```jsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
```

---

## STAP 11: RUN IT

```bash
# Install
npm install

# Run
npm run dev

# Visit: http://localhost:3000
```

---

## STAP 12: FIGMA INTEGRATION (Optional)

### In Figma:
1. Design your landing page
2. Export colors/typography as design tokens
3. Update `tailwind.config.js` with your colors

**Example:**

```javascript
export default {
  content: ["./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        primary: '#FF6B35',  // From Figma
        accent: '#003A70',   // From Figma
      },
      fontFamily: {
        display: 'Sohne',    // From Figma
        body: 'Inter',       // From Figma
      },
    },
  },
}
```

Then use in components:

```jsx
<button className="bg-primary text-white">
  {buttonText}
</button>
```

---

## STAP 13: CUSTOMIZE FOR YOUR DESIGN

Edit `src/pages/LandingPage.jsx` and update `pageConfig`:

```jsx
const pageConfig = {
  hero: {
    title: 'Your Title Here',
    subtitle: 'Your subtitle',
    cta: 'Your CTA Text',
    image: 'your-image-url',
  },
  features: [
    // Add your features
  ],
  // ... rest of config
};
```

---

## STAP 14: DEPLOY (Optional)

### To Vercel:
```bash
npm install -g vercel
vercel
```

### To Netlify:
```bash
npm run build
# Drag "dist" folder to netlify.app
```

---

## SUMMARY

```
Landing Page Stack:
├─ React 18
├─ Tailwind CSS
├─ Framer Motion (animations)
├─ Vite (build tool)
└─ Deploy: Vercel/Netlify

Components:
├─ Hero (banner + CTA)
├─ Features (grid)
├─ CTA (call-to-action)
└─ Form (contact)

Time to first page: 5 minutes
```

---

**Done! Nu kan je landing pages bouwen.** 🚀
